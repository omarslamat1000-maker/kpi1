(function () {
  const MRM = (window.MRM = window.MRM || {});
  const SESSION_KEY = "mrm-kpi-session-v1";

  function getSession() {
    try {
      return JSON.parse(sessionStorage.getItem(SESSION_KEY));
    } catch (error) {
      return null;
    }
  }

  function setSession(user) {
    const session = {
      userId: user.id,
      name: user.name,
      role: user.role,
      unitId: user.unitId,
      loggedAt: new Date().toISOString()
    };
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(session));
    return session;
  }

  function logout() {
    sessionStorage.removeItem(SESSION_KEY);
    window.location.href = "login.html";
  }

  function requireSession(options = {}) {
    const session = getSession();
    if (!session && !options.allowAnonymous) {
      window.location.href = "login.html";
      return null;
    }
    return session;
  }

  function requireAdmin(session) {
    if (session?.role !== "admin") {
      window.location.href = "dashboard.html";
      return false;
    }
    return true;
  }

  async function login(userId, password) {
    const state = await MRM.initStore();
    const user = state.users.find((item) => item.id === userId);
    const passwordHash = MRM.hashPassword(password);
    if (!user || user.passwordHash !== passwordHash) {
      throw new Error("بيانات الدخول غير صحيحة");
    }
    return setSession(user);
  }

  MRM.SESSION_KEY = SESSION_KEY;
  MRM.getSession = getSession;
  MRM.setSession = setSession;
  MRM.logout = logout;
  MRM.requireSession = requireSession;
  MRM.requireAdmin = requireAdmin;
  MRM.login = login;
})();
