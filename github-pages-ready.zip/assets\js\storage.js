(function () {
  const MRM = (window.MRM = window.MRM || {});
  const STORAGE_KEY = "mrm-kpi-state-v1";
  const DEFAULT_PASSWORD_HASH = "mrm-demo-aefd3536";
  const LEGACY_PASSWORD_HASHES = new Set(["mrm-demo-00308f83"]);
  const DEFAULT_MEASUREMENT_UNITS = ["نسبة مئوية", "عدد", "يوم", "ريال", "درجة", "كيلومتر", "بلاغ"];
  const DEFAULT_PERIOD_MONTHS = {
    "الربع الأول": [1, 2, 3],
    "الربع الثاني": [4, 5, 6],
    "الربع الثالث": [7, 8, 9],
    "الربع الرابع": [10, 11, 12]
  };

  const fallbackUnits = [
    ["studies-designs", "الوكالة المساعدة للدراسات والتصاميم", "الدراسات والتصاميم"],
    ["technical-affairs", "الوكالة المساعدة للشؤون الفنية", "الشؤون الفنية"],
    ["roads", "الوكالة المساعدة للطرق", "الطرق"],
    ["parks-humanization", "الوكالة المساعدة للحدائق والأنسنة", "الحدائق والأنسنة"],
    ["project-coordination", "إدارة تنسيق المشروعات", "تنسيق المشروعات"],
    ["private-plans", "وحدة المخططات الخاصة وتقسيمات الأراضي", "المخططات الخاصة"],
    ["municipal-operations", "مركز متابعة العمليات البلدية", "العمليات البلدية"]
  ].map(([id, name, shortName]) => ({
    id,
    name,
    shortName,
    owner: `حساب ${shortName}`
  }));

  function fallbackKpis(units) {
    return units.map((unit, index) => ({
      id: `KPI-${String(index + 1).padStart(3, "0")}`,
      unitId: unit.id,
      name: `نسبة إنجاز أعمال ${unit.shortName}`,
      domain: "الأداء العام",
      objective: "رفع كفاءة الإنجاز",
      initiative: "برنامج تحسين الأداء",
      type: index % 2 ? "تشغيلي" : "استراتيجي",
      frequency: "شهري",
      measurementUnit: "نسبة",
      polarity: "تصاعدي",
      annualTarget: 90,
      periodicTarget: 80,
      actual: 70 + index * 3,
      weight: 15,
      notes: "",
      deviationReason: "",
      correctiveAction: "",
      evidenceLink: "",
      workflowStatus: "مسودة",
      approved: false
    }));
  }

  function makeUsers(units) {
    return [
      {
        id: "admin",
        name: "مدير النظام",
        role: "admin",
        unitId: null,
        passwordHash: DEFAULT_PASSWORD_HASH,
        passwordUpdatedAt: null
      },
      ...units.map((unit, index) => ({
        id: `unit-${index + 1}`,
        name: unit.owner || `حساب ${unit.shortName}`,
        role: "unit",
        unitId: unit.id,
        passwordHash: DEFAULT_PASSWORD_HASH,
        passwordUpdatedAt: null
      }))
    ];
  }

  function makeId(prefix) {
    return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
  }

  function hashPassword(password) {
    const text = String(password || "");
    let hash = 0x811c9dc5;
    for (let index = 0; index < text.length; index += 1) {
      hash ^= text.charCodeAt(index);
      hash = Math.imul(hash, 0x01000193);
    }
    return `mrm-demo-${(hash >>> 0).toString(16).padStart(8, "0")}`;
  }

  function normalizeUserRecord(user) {
    const passwordHash = user.passwordHash || hashPassword(user.password || "demo");
    return {
      ...user,
      passwordHash: LEGACY_PASSWORD_HASHES.has(passwordHash) ? DEFAULT_PASSWORD_HASH : passwordHash,
      passwordUpdatedAt: user.passwordUpdatedAt || null
    };
  }

  function normalizeKpiRecord(kpi, index, units) {
    const unit = units.find((item) => item.id === kpi.unitId);
    const code = kpi.code || kpi.id || `KPI-${String(index + 1).padStart(3, "0")}`;
    const polarity = kpi.polarity || (kpi.performanceDirection === "خفض المؤشر" ? "تنازلي" : "تصاعدي");

    return {
      ...kpi,
      id: kpi.id || code,
      code,
      unitId: kpi.unitId || unit?.id || units[0]?.id,
      name: kpi.name || "مؤشر جديد",
      domain: kpi.domain || "عام",
      objective: kpi.objective || "",
      initiative: kpi.initiative || "",
      definition: kpi.definition || "",
      formula: kpi.formula || (polarity === "تنازلي" ? "المستهدف ÷ الفعلي × 100" : "الفعلي ÷ المستهدف × 100"),
      type: kpi.type || "تشغيلي",
      frequency: kpi.frequency || "شهري",
      measurementUnit: kpi.measurementUnit || "نسبة مئوية",
      polarity,
      performanceMethod: kpi.performanceMethod || polarity,
      performanceDirection: kpi.performanceDirection || (polarity === "تنازلي" ? "خفض المؤشر" : "رفع المؤشر"),
      baseline: Number(kpi.baseline || 0),
      lowerLimit: Number(kpi.lowerLimit || 0),
      upperLimit: Number(kpi.upperLimit || 0),
      greenThreshold: Number(kpi.greenThreshold || 90),
      yellowThreshold: Number(kpi.yellowThreshold || 70),
      allowOverAchievement: kpi.allowOverAchievement !== false,
      annualTarget: Number(kpi.annualTarget || 0),
      periodicTarget: Number(kpi.periodicTarget || kpi.annualTarget || 0),
      actual: Number(kpi.actual || 0),
      weight: Number(kpi.weight || 0),
      dataSource: kpi.dataSource || "",
      dataOwner: kpi.dataOwner || kpi.owner || unit?.name || "",
      owner: kpi.owner || unit?.name || "",
      notes: kpi.notes || "",
      deviationReason: kpi.deviationReason || "",
      correctiveAction: kpi.correctiveAction || "",
      correctiveOwner: kpi.correctiveOwner || "",
      correctiveStartDate: kpi.correctiveStartDate || "",
      correctiveDueDate: kpi.correctiveDueDate || "",
      correctiveStatus: kpi.correctiveStatus || "لم يبدأ",
      correctiveProgress: Number(kpi.correctiveProgress || 0),
      correctiveImpact: kpi.correctiveImpact || "",
      correctiveFollowupNotes: kpi.correctiveFollowupNotes || "",
      evidenceLink: kpi.evidenceLink || "",
      workflowStatus: kpi.workflowStatus || (kpi.approved ? "معتمد" : "مسودة"),
      reviewNotes: kpi.reviewNotes || "",
      approved: Boolean(kpi.approved)
    };
  }

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function uniqueList(values) {
    return Array.from(
      new Set(
        values
          .map((value) => String(value || "").trim())
          .filter(Boolean)
      )
    );
  }

  function normalizeMonths(months, period) {
    const fallback = DEFAULT_PERIOD_MONTHS[period] || DEFAULT_PERIOD_MONTHS["الربع الأول"];
    const values = Array.isArray(months) && months.length ? months : fallback;
    return Array.from(
      new Set(
        values
          .map((value) => Number(value))
          .filter((value) => Number.isInteger(value) && value >= 1 && value <= 12)
      )
    ).sort((a, b) => a - b);
  }

  function normalizePeriod(period) {
    if (DEFAULT_PERIOD_MONTHS[period]) return period;
    const monthToQuarter = {
      يناير: "الربع الأول",
      فبراير: "الربع الأول",
      مارس: "الربع الأول",
      أبريل: "الربع الثاني",
      مايو: "الربع الثاني",
      يونيو: "الربع الثاني",
      يوليو: "الربع الثالث",
      أغسطس: "الربع الثالث",
      سبتمبر: "الربع الثالث",
      أكتوبر: "الربع الرابع",
      نوفمبر: "الربع الرابع",
      ديسمبر: "الربع الرابع"
    };
    return monthToQuarter[period] || "الربع الأول";
  }

  async function readJson(path, fallback) {
    try {
      const response = await fetch(path, { cache: "no-store" });
      if (!response.ok) {
        throw new Error(`تعذر تحميل ${path}`);
      }
      return await response.json();
    } catch (error) {
      return clone(fallback);
    }
  }

  function normalizeState(state) {
    const units = Array.isArray(state.units) && state.units.length ? state.units : clone(fallbackUnits);
    const rawKpis = Array.isArray(state.kpis) && state.kpis.length ? state.kpis : fallbackKpis(units);
    const kpis = rawKpis.map((kpi, index) => normalizeKpiRecord(kpi, index, units));
    const rawUsers = Array.isArray(state.users) && state.users.length ? state.users : makeUsers(units);
    const users = rawUsers.map(normalizeUserRecord);
    const period = normalizePeriod(state.meta?.period);
    const measurementUnits = uniqueList([
      ...DEFAULT_MEASUREMENT_UNITS,
      ...(Array.isArray(state.measurementUnits) ? state.measurementUnits : []),
      ...kpis.map((kpi) => kpi.measurementUnit)
    ]);

    return {
      version: 1,
      meta: {
        appName: "برنامج مؤشرات الأداء الاستراتيجي والمبادرات",
        year: state.meta?.year || new Date().getFullYear(),
        period,
        months: normalizeMonths(state.meta?.months, period),
        periodStatus: state.meta?.periodStatus || "مفتوحة للإدخال",
        periodApprovedAt: state.meta?.periodApprovedAt || null,
        periodApprovedBy: state.meta?.periodApprovedBy || "",
        periodReturnReason: state.meta?.periodReturnReason || "",
        updatedAt: state.meta?.updatedAt || new Date().toISOString()
      },
      units,
      kpis,
      measurementUnits,
      users,
      auditLog: Array.isArray(state.auditLog) ? state.auditLog : []
    };
  }

  let cachedState = null;

  async function initStore(forceSeed) {
    if (cachedState && !forceSeed) {
      return cachedState;
    }

    if (!forceSeed) {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        try {
          cachedState = normalizeState(JSON.parse(stored));
          return cachedState;
        } catch (error) {
          localStorage.removeItem(STORAGE_KEY);
        }
      }
    }

    const units = await readJson("data/seed-units.json", fallbackUnits);
    const kpis = await readJson("data/seed-kpis.json", fallbackKpis(units));
    cachedState = normalizeState({
      meta: {
        year: new Date().getFullYear(),
        period: "الربع الأول"
      },
      units,
      kpis,
      users: makeUsers(units),
      auditLog: []
    });
    saveState(cachedState);
    return cachedState;
  }

  function saveState(state) {
    state.meta = state.meta || {};
    state.meta.updatedAt = new Date().toISOString();
    cachedState = normalizeState(state);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cachedState));
    return cachedState;
  }

  function actorName(actor) {
    return actor?.name || "النظام";
  }

  function addAudit(action, actor, details) {
    const state = cachedState;
    if (!state) return;
    state.auditLog.unshift({
      action,
      actor: actorName(actor),
      details,
      page: typeof document !== "undefined" ? document.body?.dataset?.page || "" : "",
      createdAt: new Date().toISOString()
    });
    saveState(state);
  }

  function unitName(unitId) {
    const unit = cachedState?.units?.find((item) => item.id === unitId);
    return unit?.name || "غير محدد";
  }

  function updateKpi(id, patch, actor) {
    const state = cachedState;
    const index = state.kpis.findIndex((item) => item.id === id);
    if (index === -1) return null;
    state.kpis[index] = {
      ...state.kpis[index],
      ...patch,
      updatedAt: new Date().toISOString(),
      updatedBy: actorName(actor)
    };
    saveState(state);
    addAudit("تحديث مؤشر", actor, state.kpis[index].name);
    return state.kpis[index];
  }

  function upsertKpi(kpi, actor) {
    const state = cachedState;
    const existingIndex = state.kpis.findIndex((item) => item.id === kpi.id || (kpi.code && item.code === kpi.code));
    const normalizedInput = normalizeKpiRecord(kpi, state.kpis.length, state.units);
    const base = {
      ...normalizedInput,
      approved: Boolean(kpi.approved)
    };

    if (existingIndex >= 0) {
      state.kpis[existingIndex] = {
        ...state.kpis[existingIndex],
        ...base,
        id: state.kpis[existingIndex].id,
        updatedAt: new Date().toISOString(),
        updatedBy: actorName(actor)
      };
      saveState(state);
      addAudit("تعديل مكتبة المؤشرات", actor, state.kpis[existingIndex].name);
      return state.kpis[existingIndex];
    }

    const nextNumber = state.kpis.length + 1;
    const created = {
      ...normalizeKpiRecord(
        {
          ...base,
          id: kpi.id || kpi.code || `KPI-${String(nextNumber).padStart(3, "0")}`
        },
        nextNumber - 1,
        state.units
      ),
      createdAt: new Date().toISOString(),
      createdBy: actorName(actor)
    };
    state.kpis.push(created);
    saveState(state);
    addAudit("إضافة مؤشر", actor, created.name);
    return created;
  }

  function deleteKpi(id, actor) {
    const state = cachedState;
    const removed = state.kpis.find((item) => item.id === id);
    state.kpis = state.kpis.filter((item) => item.id !== id);
    saveState(state);
    addAudit("حذف مؤشر", actor, removed?.name || id);
  }

  function approveKpis(ids, actor) {
    const state = cachedState;
    state.kpis = state.kpis.map((item) =>
      ids.includes(item.id)
        ? {
            ...item,
            approved: true,
            workflowStatus: "معتمد",
            approvedAt: new Date().toISOString(),
            approvedBy: actorName(actor)
          }
        : item
    );
    saveState(state);
    addAudit("اعتماد فترة", actor, `${ids.length} مؤشر`);
  }

  function setPeriodStatus(status, actor, reason = "") {
    const state = cachedState;
    if (!state) return null;
    state.meta.periodStatus = status;
    if (status === "معتمدة" || status === "مغلقة") {
      state.meta.periodApprovedAt = new Date().toISOString();
      state.meta.periodApprovedBy = actorName(actor);
      state.kpis = state.kpis.map((item) => ({
        ...item,
        approved: true,
        workflowStatus: "معتمد",
        approvedAt: state.meta.periodApprovedAt,
        approvedBy: actorName(actor)
      }));
    }
    if (status === "معادة للتصحيح") {
      state.meta.periodReturnReason = reason;
      state.kpis = state.kpis.map((item) => ({
        ...item,
        approved: false,
        workflowStatus: "معاد",
        reviewNotes: reason || item.reviewNotes || ""
      }));
    }
    if (status === "قيد المراجعة") {
      state.kpis = state.kpis.map((item) => ({
        ...item,
        workflowStatus: "مرسل"
      }));
    }
    saveState(state);
    addAudit("تغيير حالة الفترة", actor, `${status}${reason ? ` - ${reason}` : ""}`);
    return cachedState;
  }

  function upsertAccountRecord(account, actor) {
    const state = cachedState;
    if (!state) return null;

    const userId = account.userId || makeId("account");
    const existingUser = state.users.find((item) => item.id === userId);
    const type = account.type === "general" ? "general" : "department";
    const name = String(account.name || "").trim();
    const shortName = String(account.shortName || name).trim();
    const parentUnitId = account.parentUnitId || "";

    if (!name) return null;

    if (type === "general") {
      const nextUser = {
        ...(existingUser || {}),
        id: userId,
        name,
        role: "admin",
        unitId: null,
        accountKind: "general",
        customAccount: existingUser ? Boolean(existingUser.customAccount) : userId !== "admin",
        passwordHash: existingUser?.passwordHash || hashPassword(account.password || "demo"),
        passwordUpdatedAt: existingUser?.passwordUpdatedAt || null
      };

      if (existingUser) {
        state.users = state.users.map((user) => (user.id === userId ? nextUser : user));
      } else {
        state.users.push(nextUser);
      }
      saveState(state);
      addAudit(existingUser ? "تعديل حساب" : "إضافة حساب عام", actor, name);
      return cachedState;
    }

    const unitId = existingUser?.unitId || account.unitId || makeId("unit");
    const existingUnit = state.units.find((unit) => unit.id === unitId);
    const nextUnit = {
      ...(existingUnit || {}),
      id: unitId,
      name,
      shortName,
      owner: name,
      parentUnitId,
      customUnit: existingUnit ? Boolean(existingUnit.customUnit) : true
    };
    const nextUser = {
      ...(existingUser || {}),
      id: userId,
      name,
      role: "unit",
      unitId,
      accountKind: "department",
      parentUnitId,
      customAccount: existingUser ? Boolean(existingUser.customAccount) : true,
      passwordHash: existingUser?.passwordHash || hashPassword(account.password || "demo"),
      passwordUpdatedAt: existingUser?.passwordUpdatedAt || null
    };

    if (existingUnit) {
      state.units = state.units.map((unit) => (unit.id === unitId ? nextUnit : unit));
    } else {
      state.units.push(nextUnit);
    }

    if (existingUser) {
      state.users = state.users.map((user) => (user.id === userId ? nextUser : user));
    } else {
      state.users.push(nextUser);
    }

    saveState(state);
    addAudit(existingUser ? "تعديل نطاق وحساب" : "إضافة نطاق وحساب", actor, name);
    return cachedState;
  }

  function deleteAccountRecord(userId, actor) {
    const state = cachedState;
    const user = state?.users?.find((item) => item.id === userId);
    if (!state || !user) {
      return { ok: false, message: "الحساب غير موجود." };
    }
    if (user.id === "admin" || !user.customAccount) {
      return { ok: false, message: "لا يمكن حذف الحسابات الأساسية للنظام." };
    }

    const relatedKpis = user.unitId ? state.kpis.filter((kpi) => kpi.unitId === user.unitId).length : 0;
    if (relatedKpis) {
      return { ok: false, message: "لا يمكن حذف حساب له مؤشرات مرتبطة." };
    }

    state.users = state.users.filter((item) => item.id !== userId);
    if (user.unitId) {
      const unit = state.units.find((item) => item.id === user.unitId);
      if (unit?.customUnit) {
        state.units = state.units.filter((item) => item.id !== user.unitId);
      }
    }

    saveState(state);
    addAudit("حذف حساب", actor, user.name);
    return { ok: true, message: "تم حذف الحساب." };
  }

  function addMeasurementUnit(unitName, actor) {
    const state = cachedState;
    const value = String(unitName || "").trim();
    if (!state || !value) return state;

    const exists = state.measurementUnits.some((item) => item.trim() === value);
    if (!exists) {
      state.measurementUnits.push(value);
      saveState(state);
      addAudit("إضافة وحدة قياس", actor, value);
    }
    return cachedState;
  }

  function updateUserPassword(userId, password, actor) {
    const state = cachedState;
    const index = state.users.findIndex((item) => item.id === userId);
    if (index === -1) return null;

    state.users[index] = {
      ...state.users[index],
      passwordHash: hashPassword(password),
      passwordUpdatedAt: new Date().toISOString(),
      passwordUpdatedBy: actorName(actor)
    };
    saveState(state);
    addAudit("تعديل كلمة مرور", actor, state.users[index].name);
    return state.users[index];
  }

  function replaceState(nextState, actor) {
    cachedState = normalizeState(nextState);
    saveState(cachedState);
    addAudit("استعادة نسخة احتياطية", actor, "تم استبدال البيانات المحلية");
    return cachedState;
  }

  async function resetSeed(actor) {
    localStorage.removeItem(STORAGE_KEY);
    cachedState = null;
    const state = await initStore(true);
    addAudit("إعادة البيانات الأولية", actor, "تم تحميل بيانات seed");
    return state;
  }

  MRM.STORAGE_KEY = STORAGE_KEY;
  MRM.DEFAULT_PASSWORD_HASH = DEFAULT_PASSWORD_HASH;
  MRM.DEFAULT_MEASUREMENT_UNITS = DEFAULT_MEASUREMENT_UNITS;
  MRM.DEFAULT_PERIOD_MONTHS = DEFAULT_PERIOD_MONTHS;
  MRM.hashPassword = hashPassword;
  MRM.initStore = initStore;
  MRM.saveState = saveState;
  MRM.addAudit = addAudit;
  MRM.unitName = unitName;
  MRM.updateKpi = updateKpi;
  MRM.upsertKpi = upsertKpi;
  MRM.deleteKpi = deleteKpi;
  MRM.approveKpis = approveKpis;
  MRM.setPeriodStatus = setPeriodStatus;
  MRM.addMeasurementUnit = addMeasurementUnit;
  MRM.upsertAccountRecord = upsertAccountRecord;
  MRM.deleteAccountRecord = deleteAccountRecord;
  MRM.updateUserPassword = updateUserPassword;
  MRM.replaceState = replaceState;
  MRM.resetSeed = resetSeed;
})();
