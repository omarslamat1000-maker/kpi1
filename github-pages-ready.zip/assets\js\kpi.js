(function () {
  const MRM = (window.MRM = window.MRM || {});

  function toNumber(value) {
    const number = Number(value);
    return Number.isFinite(number) ? number : 0;
  }

  function calculatePerformance(kpi) {
    const target = toNumber(kpi.periodicTarget || kpi.annualTarget);
    const actual = toNumber(kpi.actual);
    const lowerLimit = toNumber(kpi.lowerLimit);
    const upperLimit = toNumber(kpi.upperLimit);
    const method = kpi.performanceMethod || kpi.polarity;
    const allowOverAchievement = kpi.allowOverAchievement !== false;

    if (target < 0 || actual < 0) return 0;
    if (method === "ضمن نطاق") {
      if (!lowerLimit && !upperLimit) return 0;
      const inRange = actual >= lowerLimit && actual <= upperLimit;
      if (inRange) return 100;
      const nearest = actual < lowerLimit ? lowerLimit : upperLimit;
      return nearest > 0 ? Math.max(0, 100 - (Math.abs(actual - nearest) / nearest) * 100) : 0;
    }

    if (target <= 0) return 0;
    let performance = 0;
    if (method === "إنجاز مرحلي") {
      performance = (actual / target) * 100;
    } else if (kpi.polarity === "تنازلي" || method === "تنازلي") {
      performance = actual === 0 ? 100 : (target / actual) * 100;
    } else {
      performance = (actual / target) * 100;
    }

    return allowOverAchievement ? performance : Math.min(performance, 100);
  }

  function statusFromPerformance(performance, kpi = {}) {
    const greenThreshold = toNumber(kpi.greenThreshold || 90);
    const yellowThreshold = toNumber(kpi.yellowThreshold || 70);
    if (performance >= greenThreshold) return { key: "green", label: "أخضر" };
    if (performance >= yellowThreshold) return { key: "yellow", label: "أصفر" };
    return { key: "red", label: "أحمر" };
  }

  function formatPercent(value) {
    return `${Math.round(value * 10) / 10}%`;
  }

  function calculateDataQuality(kpi) {
    const requiredFields = [
      "name",
      "code",
      "objective",
      "definition",
      "formula",
      "measurementUnit",
      "dataSource",
      "owner"
    ];
    let score = 40;
    const completed = requiredFields.filter((field) => String(kpi[field] || "").trim()).length;
    score += (completed / requiredFields.length) * 30;
    if (String(kpi.evidenceLink || "").trim()) score += 10;
    if (kpi.updatedAt || kpi.actual) score += 8;
    if (toNumber(kpi.actual) >= 0 && toNumber(kpi.periodicTarget || kpi.annualTarget) >= 0) score += 5;
    const performance = calculatePerformance(kpi);
    const status = statusFromPerformance(performance, kpi);
    if (status.key !== "green" && String(kpi.deviationReason || kpi.notes || "").trim()) score += 4;
    if (status.key === "red" && String(kpi.correctiveAction || "").trim()) score += 3;
    return Math.max(0, Math.min(100, Math.round(score)));
  }

  function enrichKpi(kpi, state) {
    const performance = calculatePerformance(kpi);
    const status = statusFromPerformance(performance, kpi);
    const unit = state.units.find((item) => item.id === kpi.unitId);
    const dataQuality = calculateDataQuality(kpi);
    return {
      ...kpi,
      unitName: unit?.name || "غير محدد",
      unitShortName: unit?.shortName || unit?.name || "غير محدد",
      performance,
      performanceText: formatPercent(performance),
      statusKey: status.key,
      statusLabel: status.label,
      dataQuality,
      dataQualityText: formatPercent(dataQuality),
      isUpdated: Boolean(kpi.updatedAt || kpi.actual),
      hasEvidence: Boolean(String(kpi.evidenceLink || "").trim())
    };
  }

  function visibleKpis(state, session) {
    const rows = state.kpis.map((kpi) => enrichKpi(kpi, state));
    if (session?.role === "unit") {
      return rows.filter((item) => item.unitId === session.unitId);
    }
    return rows;
  }

  function summarizeRows(rows) {
    const count = rows.length;
    const average = count
      ? rows.reduce((total, item) => total + item.performance, 0) / count
      : 0;
    const statusCounts = rows.reduce(
      (acc, item) => {
        acc[item.statusKey] += 1;
        return acc;
      },
      { green: 0, yellow: 0, red: 0 }
    );

    return {
      count,
      average,
      averageText: formatPercent(average),
      green: statusCounts.green,
      yellow: statusCounts.yellow,
      red: statusCounts.red,
      approved: rows.filter((item) => item.approved).length,
      notUpdated: rows.filter((item) => !item.isUpdated).length,
      withoutEvidence: rows.filter((item) => !item.hasEvidence).length,
      averageDataQuality: count ? rows.reduce((total, item) => total + item.dataQuality, 0) / count : 0,
      averageDataQualityText: formatPercent(count ? rows.reduce((total, item) => total + item.dataQuality, 0) / count : 0),
      correctiveActions: rows.filter((item) => item.correctiveAction).length
    };
  }

  function groupByUnit(rows, state) {
    return state.units
      .map((unit) => {
        const unitRows = rows.filter((row) => row.unitId === unit.id);
        const summary = summarizeRows(unitRows);
        const status = statusFromPerformance(summary.average);
        return {
          unit,
          count: unitRows.length,
          average: summary.average,
          averageText: summary.averageText,
          statusKey: status.key,
          statusLabel: status.label
        };
      })
      .filter((item) => item.count > 0)
      .sort((a, b) => b.average - a.average);
  }

  function groupCountBy(rows, field, fallbackLabel = "غير محدد") {
    const grouped = rows.reduce((acc, row) => {
      const label = row[field] || fallbackLabel;
      acc.set(label, (acc.get(label) || 0) + 1);
      return acc;
    }, new Map());

    return Array.from(grouped, ([label, count]) => ({ label, count }))
      .sort((a, b) => b.count - a.count || a.label.localeCompare(b.label, "ar"));
  }

  function groupInterventionByUnit(rows, state) {
    const riskyRows = rows.filter((row) => row.statusKey !== "green");
    return state.units
      .map((unit) => ({
        label: unit.shortName || unit.name,
        count: riskyRows.filter((row) => row.unitId === unit.id).length
      }))
      .filter((item) => item.count > 0)
      .sort((a, b) => b.count - a.count || a.label.localeCompare(b.label, "ar"));
  }

  function topBottomKpis(rows, limit = 5) {
    const sorted = [...rows].sort((a, b) => b.performance - a.performance);
    return {
      top: sorted.slice(0, limit),
      bottom: sorted.slice(-limit).reverse()
    };
  }

  MRM.calculatePerformance = calculatePerformance;
  MRM.statusFromPerformance = statusFromPerformance;
  MRM.calculateDataQuality = calculateDataQuality;
  MRM.formatPercent = formatPercent;
  MRM.enrichKpi = enrichKpi;
  MRM.visibleKpis = visibleKpis;
  MRM.summarizeRows = summarizeRows;
  MRM.groupByUnit = groupByUnit;
  MRM.groupCountBy = groupCountBy;
  MRM.groupInterventionByUnit = groupInterventionByUnit;
  MRM.topBottomKpis = topBottomKpis;
})();
