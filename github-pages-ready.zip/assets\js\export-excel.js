(function () {
  const MRM = (window.MRM = window.MRM || {});

  function timestamp() {
    return new Date().toISOString().slice(0, 10);
  }

  function downloadBlob(content, fileName, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  }

  function rowsForExport(state) {
    return state.kpis.map((kpi) => {
      const row = MRM.enrichKpi(kpi, state);
      return {
        السنة: state.meta.year,
        الفترة: state.meta.period,
        الوحدة: row.unitName,
        "رمز المؤشر": row.code || row.id,
        المؤشر: row.name,
        النوع: row.type,
        "الهدف المرتبط": row.objective,
        "المبادرة": row.initiative,
        "تعريف المؤشر": row.definition,
        "معادلة الحساب": row.formula,
        "وحدة القياس": row.measurementUnit,
        "خط الأساس": row.baseline,
        الوزن: row.weight,
        "المستهدف السنوي": row.annualTarget,
        "المستهدف المرحلي": row.periodicTarget || row.annualTarget,
        "القيمة الفعلية": row.actual,
        "نسبة الأداء": row.performanceText,
        "جودة البيانات": row.dataQualityText,
        "اتجاه الأداء المطلوب": row.performanceDirection,
        "دورية القياس": row.frequency,
        "مصدر البيانات": row.dataSource,
        "مالك البيانات": row.dataOwner,
        "مالك المؤشر": row.owner,
        الحالة: row.statusLabel,
        "حالة سير المؤشر": row.workflowStatus,
        الملاحظات: row.notes || "",
        "سبب الانحراف": row.deviationReason || "",
        "الإجراء التصحيحي": row.correctiveAction || "",
        "مالك الإجراء": row.correctiveOwner || "",
        "حالة الإجراء": row.correctiveStatus || "",
        "نسبة إنجاز الإجراء": row.correctiveProgress || 0,
        "رابط الدليل": row.evidenceLink || "",
        "تاريخ التحديث": row.updatedAt || state.meta.updatedAt,
        المستخدم: row.updatedBy || ""
      };
    });
  }

  function exportBackup(state) {
    downloadBlob(
      JSON.stringify(state, null, 2),
      `kpi-backup-${timestamp()}.json`,
      "application/json;charset=utf-8"
    );
  }

  function exportCsv(state) {
    const rows = rowsForExport(state);
    const headers = Object.keys(rows[0] || {});
    const csv = [
      headers.join(","),
      ...rows.map((row) =>
        headers
          .map((header) => `"${String(row[header] ?? "").replaceAll('"', '""')}"`)
          .join(",")
      )
    ].join("\n");
    downloadBlob(`\uFEFF${csv}`, `kpi-report-${timestamp()}.csv`, "text/csv;charset=utf-8");
  }

  function exportExcel(state) {
    const rows = rowsForExport(state);
    if (!window.XLSX) {
      exportCsv(state);
      return "تم تصدير CSV لأن مكتبة Excel غير متاحة حاليًا.";
    }

    const enriched = state.kpis.map((kpi) => MRM.enrichKpi(kpi, state));
    const workbook = XLSX.utils.book_new();
    const sheets = {
      "Executive Dashboard": [
        { المؤشر: "عدد المؤشرات", القيمة: enriched.length },
        { المؤشر: "متوسط الأداء", القيمة: MRM.summarizeRows(enriched).averageText },
        { المؤشر: "المؤشرات الحمراء", القيمة: enriched.filter((item) => item.statusKey === "red").length }
      ],
      "All KPIs": rows,
      "Unit Performance": MRM.groupByUnit(enriched, state).map((item) => ({
        الوحدة: item.unit.name,
        "عدد المؤشرات": item.count,
        "متوسط الأداء": item.averageText,
        الحالة: item.statusLabel
      })),
      "Monthly Actuals": rows.map((row) => ({
        السنة: row.السنة,
        الفترة: row.الفترة,
        الوحدة: row.الوحدة,
        "رمز المؤشر": row["رمز المؤشر"],
        المؤشر: row.المؤشر,
        "المستهدف المرحلي": row["المستهدف المرحلي"],
        "القيمة الفعلية": row["القيمة الفعلية"]
      })),
      "Red Indicators": rows.filter((row) => row.الحالة === "أحمر"),
      "Corrective Actions": rows.filter((row) => row["الإجراء التصحيحي"]),
      "Audit Log": state.auditLog || [],
      "Data Quality": enriched.map((item) => ({
        "رمز المؤشر": item.code || item.id,
        المؤشر: item.name,
        الوحدة: item.unitName,
        "جودة البيانات": item.dataQualityText,
        "له دليل": item.hasEvidence ? "نعم" : "لا",
        "محدث": item.isUpdated ? "نعم" : "لا"
      })),
      "Period Approval": [
        {
          السنة: state.meta.year,
          الفترة: state.meta.period,
          الشهور: (state.meta.months || []).join(", "),
          الحالة: state.meta.periodStatus,
          "تاريخ الاعتماد": state.meta.periodApprovedAt || "",
          المعتمد: state.meta.periodApprovedBy || "",
          "سبب الإرجاع": state.meta.periodReturnReason || ""
        }
      ]
    };

    Object.entries(sheets).forEach(([name, data]) => {
      XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(data), name);
    });

    XLSX.writeFile(workbook, `kpi-report-${timestamp()}.xlsx`);
    return "تم إنشاء ملف Excel.";
  }

  function xmlEscape(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;");
  }

  const crcTable = (() => {
    const table = new Uint32Array(256);
    for (let i = 0; i < 256; i += 1) {
      let c = i;
      for (let j = 0; j < 8; j += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      table[i] = c >>> 0;
    }
    return table;
  })();

  function crc32(bytes) {
    let crc = 0xffffffff;
    for (let i = 0; i < bytes.length; i += 1) {
      crc = crcTable[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
    }
    return (crc ^ 0xffffffff) >>> 0;
  }

  function dosDateTime(date = new Date()) {
    const time =
      ((date.getHours() & 0x1f) << 11) |
      ((date.getMinutes() & 0x3f) << 5) |
      ((Math.floor(date.getSeconds() / 2) & 0x1f));
    const day =
      (((date.getFullYear() - 1980) & 0x7f) << 9) |
      (((date.getMonth() + 1) & 0x0f) << 5) |
      (date.getDate() & 0x1f);
    return { time, day };
  }

  function u16(view, offset, value) {
    view.setUint16(offset, value, true);
  }

  function u32(view, offset, value) {
    view.setUint32(offset, value >>> 0, true);
  }

  function concatBytes(parts) {
    const size = parts.reduce((sum, part) => sum + part.length, 0);
    const output = new Uint8Array(size);
    let offset = 0;
    parts.forEach((part) => {
      output.set(part, offset);
      offset += part.length;
    });
    return output;
  }

  function zipStore(files) {
    const encoder = new TextEncoder();
    const chunks = [];
    const central = [];
    let offset = 0;
    const { time, day } = dosDateTime();

    files.forEach(({ name, content }) => {
      const nameBytes = encoder.encode(name);
      const dataBytes = content instanceof Uint8Array ? content : encoder.encode(content);
      const crc = crc32(dataBytes);

      const local = new Uint8Array(30);
      const localView = new DataView(local.buffer);
      u32(localView, 0, 0x04034b50);
      u16(localView, 4, 20);
      u16(localView, 6, 0x0800);
      u16(localView, 8, 0);
      u16(localView, 10, time);
      u16(localView, 12, day);
      u32(localView, 14, crc);
      u32(localView, 18, dataBytes.length);
      u32(localView, 22, dataBytes.length);
      u16(localView, 26, nameBytes.length);
      u16(localView, 28, 0);
      chunks.push(local, nameBytes, dataBytes);

      const header = new Uint8Array(46);
      const view = new DataView(header.buffer);
      u32(view, 0, 0x02014b50);
      u16(view, 4, 20);
      u16(view, 6, 20);
      u16(view, 8, 0x0800);
      u16(view, 10, 0);
      u16(view, 12, time);
      u16(view, 14, day);
      u32(view, 16, crc);
      u32(view, 20, dataBytes.length);
      u32(view, 24, dataBytes.length);
      u16(view, 28, nameBytes.length);
      u16(view, 30, 0);
      u16(view, 32, 0);
      u16(view, 34, 0);
      u16(view, 36, 0);
      u32(view, 38, 0);
      u32(view, 42, offset);
      central.push(header, nameBytes);

      offset += local.length + nameBytes.length + dataBytes.length;
    });

    const centralBytes = concatBytes(central);
    const end = new Uint8Array(22);
    const endView = new DataView(end.buffer);
    u32(endView, 0, 0x06054b50);
    u16(endView, 4, 0);
    u16(endView, 6, 0);
    u16(endView, 8, files.length);
    u16(endView, 10, files.length);
    u32(endView, 12, centralBytes.length);
    u32(endView, 16, offset);
    u16(endView, 20, 0);

    return concatBytes([...chunks, centralBytes, end]);
  }

  function pptTextShape(id, x, y, w, h, text, options = {}) {
    const size = options.size || 2400;
    const color = options.color || "103B37";
    const bold = options.bold ? ' b="1"' : "";
    const paragraphs = String(text || "")
      .split("\n")
      .filter(Boolean)
      .map(
        (line) => `<a:p><a:pPr algn="${options.align || "r"}" rtl="1"/><a:r><a:rPr lang="ar-SA" sz="${size}"${bold}><a:solidFill><a:srgbClr val="${color}"/></a:solidFill><a:latin typeface="Arial"/><a:ea typeface="Arial"/></a:rPr><a:t>${xmlEscape(line)}</a:t></a:r></a:p>`
      )
      .join("");
    return `<p:sp>
      <p:nvSpPr><p:cNvPr id="${id}" name="Text ${id}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>
      <p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${w}" cy="${h}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/><a:ln><a:noFill/></a:ln></p:spPr>
      <p:txBody><a:bodyPr rtlCol="1" anchor="${options.anchor || "ctr"}"/><a:lstStyle/>${paragraphs}</p:txBody>
    </p:sp>`;
  }

  function pptRect(id, x, y, w, h, fill, radius = "roundRect") {
    return `<p:sp>
      <p:nvSpPr><p:cNvPr id="${id}" name="Shape ${id}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
      <p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${w}" cy="${h}"/></a:xfrm><a:prstGeom prst="${radius}"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val="${fill}"/></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr>
    </p:sp>`;
  }

  function pptSlide(shapes) {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
      <p:cSld><p:spTree>
        <p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>
        <p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>
        ${shapes.join("")}
      </p:spTree></p:cSld>
      <p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr>
    </p:sld>`;
  }

  function buildPptx(state) {
    const enriched = state.kpis.map((kpi) => MRM.enrichKpi(kpi, state));
    const summary = MRM.summarizeRows(enriched);
    const units = MRM.groupByUnit(enriched, state).slice(0, 6);
    const redRows = enriched.filter((item) => item.statusKey === "red").slice(0, 6);
    const statusLines = [
      `إجمالي المؤشرات: ${summary.count}`,
      `متوسط الأداء: ${summary.averageText}`,
      `المعتمدة: ${summary.approved}`,
      `غير المعتمدة: ${summary.count - summary.approved}`,
      `جودة البيانات: ${summary.averageDataQualityText || "غير متاح"}`
    ].join("\n");
    const statusCounts = [
      `خضراء: ${summary.green}`,
      `صفراء: ${summary.yellow}`,
      `حمراء: ${summary.red}`
    ].join("\n");
    const unitLines = units
      .map((item) => `${item.unit.shortName || item.unit.name}: ${item.averageText} (${item.count})`)
      .join("\n");
    const redLines = redRows.length
      ? redRows.map((item) => `${item.name} - ${item.unitName} - ${item.performanceText}`).join("\n")
      : "لا توجد مؤشرات حمراء ضمن البيانات الحالية.";

    const slides = [
      pptSlide([
        pptRect(2, 0, 0, 12192000, 6858000, "F3FAF7", "rect"),
        pptRect(3, 0, 0, 12192000, 1850000, "006B5F", "rect"),
        pptTextShape(4, 900000, 440000, 10400000, 720000, "برنامج مؤشرات الأداء", { size: 4200, color: "FFFFFF", bold: true }),
        pptTextShape(5, 900000, 1180000, 10400000, 420000, `تقرير تنفيذي - ${state.meta.period || ""} ${state.meta.year || ""}`, { size: 2400, color: "DDF1EA" }),
        pptTextShape(6, 900000, 2580000, 10400000, 1300000, "أمانة منطقة المدينة المنورة\nمنصة متابعة المؤشرات والمستهدفات والإجراءات التصحيحية", { size: 3000, color: "103B37", bold: true })
      ]),
      pptSlide([
        pptTextShape(2, 700000, 350000, 10800000, 540000, "الملخص التنفيذي", { size: 3600, bold: true }),
        pptRect(3, 700000, 1200000, 5000000, 3600000, "E8F5F1"),
        pptRect(4, 6200000, 1200000, 5000000, 3600000, "F8FBFA"),
        pptTextShape(5, 1050000, 1500000, 4300000, 2900000, statusLines, { size: 2300 }),
        pptTextShape(6, 6550000, 1500000, 4300000, 2900000, statusCounts, { size: 2600, bold: true })
      ]),
      pptSlide([
        pptTextShape(2, 700000, 350000, 10800000, 540000, "أداء الوحدات", { size: 3600, bold: true }),
        pptTextShape(3, 900000, 1250000, 10000000, 4200000, unitLines || "لا توجد بيانات وحدات.", { size: 2400 })
      ]),
      pptSlide([
        pptTextShape(2, 700000, 350000, 10800000, 540000, "المؤشرات التي تحتاج متابعة", { size: 3600, bold: true }),
        pptTextShape(3, 800000, 1200000, 10600000, 4500000, redLines, { size: 2200 })
      ]),
      pptSlide([
        pptTextShape(2, 700000, 350000, 10800000, 540000, "التوصيات", { size: 3600, bold: true }),
        pptTextShape(3, 900000, 1200000, 10400000, 4200000, "مراجعة المؤشرات الحمراء وربطها بإجراءات تصحيحية محددة.\nاستكمال روابط الأدلة للمؤشرات منخفضة جودة البيانات.\nاعتماد الفترة بعد اكتمال تحديثات الوحدات.\nمتابعة المؤشرات ذات الأداء الأصفر قبل تحولها إلى مخاطر تنفيذية.", { size: 2400 })
      ])
    ];

    const slideOverrides = slides
      .map((_, index) => `<Override PartName="/ppt/slides/slide${index + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>`)
      .join("");
    const slideIds = slides
      .map((_, index) => `<p:sldId id="${256 + index}" r:id="rId${index + 1}"/>`)
      .join("");
    const slideRels = slides
      .map((_, index) => `<Relationship Id="rId${index + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide${index + 1}.xml"/>`)
      .join("");

    const files = [
      {
        name: "[Content_Types].xml",
        content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>${slideOverrides}<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>`
      },
      {
        name: "_rels/.rels",
        content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>`
      },
      {
        name: "ppt/presentation.xml",
        content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:sldIdLst>${slideIds}</p:sldIdLst><p:sldSz cx="12192000" cy="6858000" type="wide"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>`
      },
      {
        name: "ppt/_rels/presentation.xml.rels",
        content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${slideRels}</Relationships>`
      },
      {
        name: "docProps/core.xml",
        content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>تقرير مؤشرات الأداء</dc:title><dc:creator>MRM KPI</dc:creator><cp:lastModifiedBy>MRM KPI</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">${new Date().toISOString()}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">${new Date().toISOString()}</dcterms:modified></cp:coreProperties>`
      },
      {
        name: "docProps/app.xml",
        content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>MRM KPI</Application><PresentationFormat>Widescreen</PresentationFormat><Slides>${slides.length}</Slides></Properties>`
      },
      ...slides.map((content, index) => ({ name: `ppt/slides/slide${index + 1}.xml`, content }))
    ];

    return zipStore(files);
  }

  function exportPowerPoint(state) {
    const pptxBytes = buildPptx(state);
    downloadBlob(
      pptxBytes,
      `kpi-presentation-${timestamp()}.pptx`,
      "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    );
    return "تم إنشاء ملف PowerPoint.";
  }

  function exportPdfReport(state) {
    const rows = state.kpis.map((kpi) => MRM.enrichKpi(kpi, state));
    const summary = MRM.summarizeRows(rows);
    const tableRows = rows
      .map(
        (row) => `<tr><td>${xmlEscape(row.name)}</td><td>${xmlEscape(row.unitName)}</td><td>${xmlEscape(row.performanceText)}</td><td>${xmlEscape(row.statusLabel)}</td><td>${xmlEscape(row.dataQualityText || "")}</td></tr>`
      )
      .join("");
    const reportHtml = `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>تقرير مؤشرات الأداء</title><style>body{font-family:Tahoma,Arial,sans-serif;margin:32px;color:#103b37}h1{color:#006b5f}table{width:100%;border-collapse:collapse;margin-top:24px}th,td{border:1px solid #d8e8e2;padding:10px;text-align:right}th{background:#e8f5f1}.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.card{border:1px solid #d8e8e2;border-radius:10px;padding:14px}.card strong{display:block;font-size:26px;color:#006b5f}@media print{button{display:none}}</style></head><body><button onclick="window.print()">حفظ PDF / طباعة</button><h1>تقرير مؤشرات الأداء</h1><p>${xmlEscape(state.meta.period || "")} - ${xmlEscape(state.meta.year || "")}</p><section class="cards"><div class="card">إجمالي المؤشرات<strong>${summary.count}</strong></div><div class="card">متوسط الأداء<strong>${summary.averageText}</strong></div><div class="card">مؤشرات حمراء<strong>${summary.red}</strong></div><div class="card">جودة البيانات<strong>${summary.averageDataQualityText || ""}</strong></div></section><table><thead><tr><th>المؤشر</th><th>الوحدة</th><th>الأداء</th><th>الحالة</th><th>جودة البيانات</th></tr></thead><tbody>${tableRows}</tbody></table><script>setTimeout(function(){window.print()},300)</script></body></html>`;
    const printWindow = window.open("", "_blank");
    if (!printWindow) return "تعذر فتح نافذة PDF. اسمح بالنوافذ المنبثقة ثم أعد المحاولة.";
    printWindow.document.open();
    printWindow.document.write(reportHtml);
    printWindow.document.close();
    return "تم فتح تقرير PDF. اختر حفظ كملف PDF من نافذة الطباعة.";
  }

  MRM.rowsForExport = rowsForExport;
  MRM.exportBackup = exportBackup;
  MRM.exportCsv = exportCsv;
  MRM.exportExcel = exportExcel;
  MRM.exportPowerPoint = exportPowerPoint;
  MRM.exportPdfReport = exportPdfReport;
})();
