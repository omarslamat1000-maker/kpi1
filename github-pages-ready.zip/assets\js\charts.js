(function () {
  const MRM = (window.MRM = window.MRM || {});
  const chartRegistry = {};

  const palette = {
    primary: "#0f5f57",
    teal: "#2f857a",
    accent: "#7fbd5d",
    target: "#0f5f57",
    actual: "#87c65f",
    green: "#1f8a61",
    yellow: "#d49a2a",
    red: "#c84646",
    muted: "#6b7c79",
    track: "#e7f0ed",
    ink: "#0d1f1d"
  };
  const chartFont = '"MRM TheSans Arabic", "Segoe UI", Tahoma, Arial, sans-serif';

  function getCanvas(id) {
    const canvas = document.getElementById(id);
    return canvas?.getContext ? canvas : null;
  }

  function resizeCanvas(canvas, height = 260) {
    const ratio = window.devicePixelRatio || 1;
    const width = Math.max(canvas.clientWidth || 320, 260);
    canvas.width = width * ratio;
    canvas.height = height * ratio;
    const context = canvas.getContext("2d");
    context.setTransform(ratio, 0, 0, ratio, 0, 0);
    context.clearRect(0, 0, width, height);
    context.font = `13px ${chartFont}`;
    return { context, width, height };
  }

  function emptyFallback(canvas, message = "لا توجد بيانات") {
    const { context, width, height } = resizeCanvas(canvas);
    context.fillStyle = palette.muted;
    context.textAlign = "center";
    context.fillText(message, width / 2, height / 2);
  }

  function destroyChart(key) {
    if (chartRegistry[key]) {
      chartRegistry[key].destroy();
      chartRegistry[key] = null;
    }
  }

  function chartOptions(type) {
    const axisOptions = {
      responsive: true,
      maintainAspectRatio: false,
      indexAxis: type === "horizontalBar" ? "y" : "x",
      plugins: {
        legend: { display: false },
        tooltip: { rtl: true, textDirection: "rtl" }
      },
      scales: {
        x: { beginAtZero: true, grid: { color: "rgba(13,31,29,.08)" }, ticks: { font: { family: chartFont } } },
        y: { beginAtZero: true, grid: { color: "rgba(13,31,29,.08)" }, ticks: { font: { family: chartFont } } }
      }
    };

    if (type === "doughnut") {
      return {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: "bottom", labels: { usePointStyle: true, font: { family: chartFont } } },
          tooltip: { rtl: true, textDirection: "rtl" }
        }
      };
    }

    return axisOptions;
  }

  function drawFallbackBar(canvas, labels, values, options = {}) {
    if (!labels.length) {
      emptyFallback(canvas);
      return;
    }

    const { context, width } = resizeCanvas(canvas, options.height || 260);
    const max = Math.max(1, options.max || 0, ...values);
    const barHeight = 20;
    const rowGap = Math.max(30, Math.min(40, 220 / labels.length));
    const labelWidth = options.labelWidth || 138;
    context.textAlign = "right";

    labels.forEach((label, index) => {
      const y = 24 + index * rowGap;
      const value = values[index];
      const availableWidth = Math.max(80, width - labelWidth - 44);
      const barWidth = Math.max(value > 0 ? 8 : 0, (value / max) * availableWidth);
      context.fillStyle = palette.track;
      context.fillRect(20, y, availableWidth, barHeight);
      context.fillStyle = options.color || palette.primary;
      context.fillRect(20, y, barWidth, barHeight);
      context.fillStyle = palette.ink;
      context.fillText(String(label).slice(0, 28), width - 18, y + 15);
      context.fillStyle = palette.muted;
      context.textAlign = "left";
      context.fillText(options.percent ? `${Math.round(value)}%` : String(value), 24, y + 15);
      context.textAlign = "right";
    });
  }

  function drawFallbackGroupedBar(canvas, labels, targetValues, actualValues, options = {}) {
    if (!labels.length) {
      emptyFallback(canvas);
      return;
    }

    const { context, width } = resizeCanvas(canvas, options.height || 300);
    const max = Math.max(1, options.max || 0, ...targetValues, ...actualValues);
    const rowGap = Math.max(42, Math.min(58, 280 / labels.length));
    const labelWidth = options.labelWidth || 138;
    const availableWidth = Math.max(90, width - labelWidth - 58);
    context.textAlign = "right";

    context.fillStyle = palette.target;
    context.fillRect(24, 10, 14, 14);
    context.fillStyle = palette.ink;
    context.textAlign = "left";
    context.fillText("المستهدف", 44, 22);
    context.fillStyle = palette.actual;
    context.fillRect(126, 10, 14, 14);
    context.fillStyle = palette.ink;
    context.fillText("الفعلي", 146, 22);

    labels.forEach((label, index) => {
      const y = 42 + index * rowGap;
      const target = targetValues[index] || 0;
      const actual = actualValues[index] || 0;
      const targetWidth = Math.max(target > 0 ? 8 : 0, (target / max) * availableWidth);
      const actualWidth = Math.max(actual > 0 ? 8 : 0, (actual / max) * availableWidth);

      context.fillStyle = palette.track;
      context.fillRect(20, y, availableWidth, 16);
      context.fillRect(20, y + 20, availableWidth, 16);
      context.fillStyle = palette.target;
      context.fillRect(20, y, targetWidth, 16);
      context.fillStyle = palette.actual;
      context.fillRect(20, y + 20, actualWidth, 16);

      context.fillStyle = palette.ink;
      context.textAlign = "right";
      context.fillText(String(label).slice(0, 28), width - 18, y + 26);
      context.fillStyle = palette.muted;
      context.textAlign = "left";
      context.fillText(`${Math.round(actual)}%`, 24, y + 54);
    });
  }

  function drawFallbackDonut(canvas, values) {
    const activeValues = values.filter((item) => item.value > 0);
    if (!activeValues.length) {
      emptyFallback(canvas);
      return;
    }

    const { context, width, height } = resizeCanvas(canvas, 260);
    const total = activeValues.reduce((sum, item) => sum + item.value, 0) || 1;
    let start = -Math.PI / 2;
    const centerX = width / 2;
    const centerY = Math.min(112, height / 2);

    activeValues.forEach((item) => {
      const angle = (item.value / total) * Math.PI * 2;
      context.beginPath();
      context.moveTo(centerX, centerY);
      context.arc(centerX, centerY, 82, start, start + angle);
      context.closePath();
      context.fillStyle = item.color;
      context.fill();
      start += angle;
    });

    context.beginPath();
    context.arc(centerX, centerY, 48, 0, Math.PI * 2);
    context.fillStyle = "#fff";
    context.fill();
    context.font = `14px ${chartFont}`;
    context.fillStyle = palette.ink;
    context.textAlign = "center";
    context.fillText(`الإجمالي ${total}`, centerX, centerY + 5);
  }

  function renderBarChart(canvasId, registryKey, items, options = {}) {
    const canvas = getCanvas(canvasId);
    if (!canvas) return;
    const labels = items.map((item) => item.label);
    const values = items.map((item) => item.value ?? item.count ?? 0);

    if (!items.length) {
      destroyChart(registryKey);
      emptyFallback(canvas);
      return;
    }

    if (window.Chart) {
      destroyChart(registryKey);
      chartRegistry[registryKey] = new Chart(canvas, {
        type: "bar",
        data: {
          labels,
          datasets: [
            {
              data: values,
              backgroundColor: options.color || palette.primary,
              borderRadius: 8
            }
          ]
        },
        options: chartOptions(options.horizontal ? "horizontalBar" : "bar")
      });
      return;
    }

    drawFallbackBar(canvas, labels, values, {
      color: options.color,
      percent: options.percent,
      max: options.max,
      labelWidth: options.labelWidth
    });
  }

  function renderGroupedUnitChart(canvasId, registryKey, items, options = {}) {
    const canvas = getCanvas(canvasId);
    if (!canvas) return;
    const labels = items.map((item) => item.label);
    const targetValues = items.map((item) => item.target ?? 100);
    const actualValues = items.map((item) => item.actual ?? 0);

    if (!items.length) {
      destroyChart(registryKey);
      emptyFallback(canvas);
      return;
    }

    if (window.Chart) {
      destroyChart(registryKey);
      chartRegistry[registryKey] = new Chart(canvas, {
        type: "bar",
        data: {
          labels,
          datasets: [
            {
              label: "المستهدف",
              data: targetValues,
              backgroundColor: palette.target,
              borderRadius: 8,
              barPercentage: 0.72,
              categoryPercentage: 0.7
            },
            {
              label: "الفعلي",
              data: actualValues,
              backgroundColor: palette.actual,
              borderRadius: 8,
              barPercentage: 0.72,
              categoryPercentage: 0.7
            }
          ]
        },
        options: {
          ...chartOptions("horizontalBar"),
          plugins: {
            legend: {
              display: true,
              position: "bottom",
              labels: { usePointStyle: true, font: { family: chartFont } }
            },
            tooltip: { rtl: true, textDirection: "rtl" }
          },
          scales: {
            x: {
              beginAtZero: true,
              suggestedMax: options.max || 120,
              grid: { color: "rgba(13,31,29,.08)" },
              ticks: {
                font: { family: chartFont },
                callback: (value) => `${value}%`
              }
            },
            y: {
              grid: { color: "rgba(13,31,29,.08)" },
              ticks: { font: { family: chartFont } }
            }
          }
        }
      });
      return;
    }

    drawFallbackGroupedBar(canvas, labels, targetValues, actualValues, {
      max: options.max || 120,
      labelWidth: options.labelWidth
    });
  }

  function renderDonutChart(canvasId, registryKey, items) {
    const canvas = getCanvas(canvasId);
    if (!canvas) return;
    const activeItems = items.filter((item) => item.value > 0);

    if (!items.length || !activeItems.length) {
      destroyChart(registryKey);
      emptyFallback(canvas);
      return;
    }

    if (window.Chart) {
      destroyChart(registryKey);
      chartRegistry[registryKey] = new Chart(canvas, {
        type: "doughnut",
        data: {
          labels: items.map((item) => item.label),
          datasets: [
            {
              data: items.map((item) => item.value),
              backgroundColor: items.map((item) => item.color),
              borderWidth: 0
            }
          ]
        },
        options: chartOptions("doughnut")
      });
      return;
    }

    drawFallbackDonut(canvas, activeItems);
  }

  function statusItems(summary) {
    return [
      { label: "أخضر", value: summary.green, color: palette.green },
      { label: "أصفر", value: summary.yellow, color: palette.yellow },
      { label: "أحمر", value: summary.red, color: palette.red }
    ];
  }

  function renderUnitChart(rows, state, canvasId = "unitPerformanceChart") {
    const grouped = MRM.groupByUnit(rows, state).map((item) => ({
      label: item.unit.shortName,
      target: 100,
      actual: Number(item.average.toFixed(1))
    }));
    renderGroupedUnitChart(canvasId, canvasId, grouped, {
      max: 120,
      labelWidth: 138
    });
  }

  function renderStatusChart(summary, canvasId = "statusDistributionChart") {
    renderDonutChart(canvasId, canvasId, statusItems(summary));
  }

  function renderTypeChart(rows, canvasId = "typeDistributionChart") {
    const items = MRM.groupCountBy(rows, "type").map((item) => ({ label: item.label, value: item.count }));
    renderBarChart(canvasId, canvasId, items, { color: palette.teal });
  }

  function renderFrequencyChart(rows, canvasId = "frequencyDistributionChart") {
    const items = MRM.groupCountBy(rows, "frequency").map((item) => ({ label: item.label, value: item.count }));
    renderBarChart(canvasId, canvasId, items, { color: palette.accent });
  }

  function renderOwnerChart(rows, canvasId = "reportOwnerDistributionChart") {
    const items = MRM.groupCountBy(rows, "owner", "غير محدد")
      .slice(0, 10)
      .map((item) => ({ label: item.label, value: item.count }));
    renderBarChart(canvasId, canvasId, items, {
      color: palette.primary,
      horizontal: true,
      labelWidth: 190
    });
  }

  function renderInterventionChart(rows, state, canvasId = "interventionChart") {
    const items = MRM.groupInterventionByUnit(rows, state).map((item) => ({ label: item.label, value: item.count }));
    renderBarChart(canvasId, canvasId, items, {
      color: palette.red,
      horizontal: true
    });
  }

  function renderTopBottomKpisChart(rows, mode = "top", canvasId = "topKpisChart") {
    const groups = MRM.topBottomKpis(rows, 5);
    const source = mode === "bottom" ? groups.bottom : groups.top;
    const items = source.map((item) => ({
      label: item.name,
      value: Number(item.performance.toFixed(1))
    }));
    renderBarChart(canvasId, canvasId, items, {
      color: mode === "bottom" ? palette.yellow : palette.green,
      percent: true,
      max: Math.max(120, ...items.map((item) => item.value)),
      horizontal: true,
      labelWidth: 210
    });
  }

  MRM.renderUnitChart = renderUnitChart;
  MRM.renderStatusChart = renderStatusChart;
  MRM.renderTypeChart = renderTypeChart;
  MRM.renderFrequencyChart = renderFrequencyChart;
  MRM.renderOwnerChart = renderOwnerChart;
  MRM.renderInterventionChart = renderInterventionChart;
  MRM.renderTopBottomKpisChart = renderTopBottomKpisChart;
})();
