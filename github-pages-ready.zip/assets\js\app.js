(function () {
  const MRM = (window.MRM = window.MRM || {});

  const statusClass = {
    green: "status-green",
    yellow: "status-yellow",
    red: "status-red"
  };
  const monthLabels = [
    "شهر 1",
    "شهر 2",
    "شهر 3",
    "شهر 4",
    "شهر 5",
    "شهر 6",
    "شهر 7",
    "شهر 8",
    "شهر 9",
    "شهر 10",
    "شهر 11",
    "شهر 12"
  ];

  function $(selector, root = document) {
    return root.querySelector(selector);
  }

  function $all(selector, root = document) {
    return Array.from(root.querySelectorAll(selector));
  }

  function escapeHtml(value) {
    const element = document.createElement("div");
    element.textContent = value ?? "";
    return element.innerHTML;
  }

  function statusBadge(key, label) {
    return `<span class="status-badge ${statusClass[key] || "status-neutral"}">${escapeHtml(label)}</span>`;
  }

  function emptyRow(message, colspan) {
    return `<tr><td colspan="${colspan}" class="empty-state">${escapeHtml(message)}</td></tr>`;
  }

  function unitOptions(units, selectedId, includeAll) {
    const allOption = includeAll ? `<option value="all">كل الوحدات</option>` : "";
    return `${allOption}${units
      .map(
        (unit) =>
          `<option value="${unit.id}" ${unit.id === selectedId ? "selected" : ""}>${escapeHtml(unit.name)}</option>`
      )
      .join("")}`;
  }

  function optionList(options, selected) {
    return options
      .map((option) => `<option value="${escapeHtml(option)}" ${option === selected ? "selected" : ""}>${escapeHtml(option)}</option>`)
      .join("");
  }

  function injectNewKpiButton(page, session) {
    const pages = new Set(["dashboard", "unit-entry", "kpi-library", "reports"]);
    const heading = $(".page-heading");
    if (!heading || !pages.has(page) || !["admin", "unit"].includes(session.role)) return;
    if ($("[data-new-kpi]", heading)) return;

    const actions = document.createElement("div");
    actions.className = "page-heading-actions";
    actions.innerHTML = `<button type="button" class="button primary" data-new-kpi>${session.role === "admin" ? "مؤشر جديد" : "إرسال مؤشر جديد للاعتماد"}</button>`;
    heading.appendChild(actions);
  }

  function initKpiComposer(state, session) {
    if (!["admin", "unit"].includes(session.role)) return;
    const composerUnits = session.role === "unit"
      ? state.units.filter((unit) => unit.id === session.unitId)
      : state.units;
    const defaultMeasurementUnit = state.measurementUnits?.[0] || MRM.DEFAULT_MEASUREMENT_UNITS?.[0] || "نسبة مئوية";

    function measurementOptions(selected) {
      return optionList(state.measurementUnits?.length ? state.measurementUnits : MRM.DEFAULT_MEASUREMENT_UNITS, selected || defaultMeasurementUnit);
    }

    const modal = document.createElement("div");
    modal.className = "modal-overlay";
    modal.id = "kpiComposer";
    modal.hidden = true;
    modal.innerHTML = `
      <section class="modal-card" role="dialog" aria-modal="true" aria-labelledby="kpiComposerTitle">
        <div class="modal-header">
          <div>
            <p class="eyebrow">مكتبة المؤشرات</p>
            <h2 id="kpiComposerTitle">مؤشر جديد</h2>
          </div>
          <button type="button" class="button ghost small-button" data-close-kpi-modal>إغلاق</button>
        </div>
        <form id="kpiComposerForm" class="grid-form modal-form">
          <input type="hidden" name="id">
          <label>
            الجهة المالكة
            <select name="unitId" required>${unitOptions(composerUnits, composerUnits[0]?.id, false)}</select>
          </label>
          <label>
            اسم المؤشر
            <input name="name" required placeholder="مثال: نسبة إنجاز مشاريع الطرق">
          </label>
          <label>
            رمز المؤشر
            <input name="code" required placeholder="INF-KPI-01">
          </label>
          <label>
            نوع المؤشر
            <select name="type" required>${optionList(["استراتيجي", "تشغيلي", "مالي", "جودة", "زمني", "امتثال", "رضا مستفيدين"], "تشغيلي")}</select>
          </label>
          <label>
            الهدف المرتبط
            <input name="objective" required placeholder="رفع كفاءة تنفيذ مشاريع البنية التحتية">
          </label>
          <label>
            المبادرة أو البرنامج المرتبط
            <input name="initiative" placeholder="مثال: برنامج تحسين البنية التحتية">
          </label>
          <label>
            دورية القياس
            <select name="frequency" required>${optionList(["يومي", "أسبوعي", "شهري", "ربعي", "نصف سنوي", "سنوي"], "شهري")}</select>
          </label>
          <label class="wide-field">
            تعريف المؤشر
            <textarea name="definition" required placeholder="شرح واضح لما يقيسه المؤشر بالضبط"></textarea>
          </label>
          <label class="wide-field">
            معادلة الحساب
            <textarea name="formula" required placeholder="عدد المشاريع المنجزة ÷ إجمالي المشاريع × 100"></textarea>
          </label>
          <label class="field-with-action">
            وحدة القياس
            <div class="select-action-row">
              <select name="measurementUnit" required>${measurementOptions(defaultMeasurementUnit)}</select>
              <button type="button" class="button ghost inline-add-button" data-add-measurement-unit title="إضافة وحدة قياس جديدة" aria-label="إضافة وحدة قياس جديدة">+</button>
            </div>
          </label>
          <label>
            خط الأساس
            <input name="baseline" type="number" min="0" step="0.01" value="0">
          </label>
          <label>
            المستهدف السنوي
            <input name="annualTarget" type="number" min="0" step="0.01" required>
          </label>
          <label>
            المستهدف المرحلي
            <input name="periodicTarget" type="number" min="0" step="0.01" required>
          </label>
          <label>
            القيمة الفعلية
            <input name="actual" type="number" min="0" step="0.01" required>
          </label>
          <label>
            نسبة الإنجاز
            <input name="performancePreview" type="text" value="0%" readonly>
          </label>
          <label>
            اتجاه الأداء المطلوب
            <select name="polarity" required>
              <option value="تصاعدي">رفع المؤشر</option>
              <option value="تنازلي">خفض المؤشر</option>
              <option value="ضمن نطاق">ضمن نطاق</option>
              <option value="إنجاز مرحلي">إنجاز مرحلي</option>
            </select>
          </label>
          <label>
            حد الأخضر
            <input name="greenThreshold" type="number" min="0" step="0.01" value="90">
          </label>
          <label>
            حد الأصفر
            <input name="yellowThreshold" type="number" min="0" step="0.01" value="70">
          </label>
          <label>
            مصدر البيانات
            <input name="dataSource" required placeholder="النظام أو الإدارة أو التقرير">
          </label>
          <label>
            مالك المؤشر
            <input name="owner" required placeholder="الجهة المسؤولة عن تحقيق المؤشر">
          </label>
          <label>
            مالك البيانات
            <input name="dataOwner" placeholder="المسؤول عن جودة وتزويد البيانات">
          </label>
          <label>
            رابط الدليل
            <input name="evidenceLink" type="url" placeholder="https://...">
          </label>
          <label class="wide-field">
            سبب الانحراف
            <textarea name="deviationReason" placeholder="يُستخدم عند انخفاض الأداء عن المستهدف"></textarea>
          </label>
          <label>
            مالك الإجراء التصحيحي
            <input name="correctiveOwner" placeholder="المسؤول عن تنفيذ الإجراء">
          </label>
          <label>
            حالة الإجراء التصحيحي
            <select name="correctiveStatus">${optionList(["لم يبدأ", "جارٍ", "متأخر", "مكتمل"], "لم يبدأ")}</select>
          </label>
          <label>
            نسبة إنجاز الإجراء
            <input name="correctiveProgress" type="number" min="0" max="100" step="1" value="0">
          </label>
          <p id="kpiComposerMessage" class="form-message wide-field" role="status"></p>
          <div class="form-actions">
            <button type="submit" class="button primary">حفظ المؤشر</button>
            <button type="button" class="button ghost" data-close-kpi-modal>إلغاء</button>
          </div>
        </form>
      </section>
    `;
    document.body.appendChild(modal);

    const form = $("#kpiComposerForm", modal);
    const message = $("#kpiComposerMessage", modal);

    function refreshMeasurementOptions(selected) {
      const select = form.elements.measurementUnit;
      const value = selected || select.value || defaultMeasurementUnit;
      select.innerHTML = measurementOptions(value);
      select.value = value;
    }

    function updatePreview() {
      const performance = MRM.calculatePerformance({
        periodicTarget: form.elements.periodicTarget.value,
        annualTarget: form.elements.annualTarget.value,
        actual: form.elements.actual.value,
        polarity: form.elements.polarity.value,
        performanceMethod: form.elements.polarity.value
      });
      form.elements.performancePreview.value = MRM.formatPercent(performance);
    }

    function openModal(kpi) {
      form.reset();
      message.textContent = "";
      form.elements.unitId.innerHTML = unitOptions(
        composerUnits,
        kpi?.unitId || $("#entryUnitSelect")?.value || composerUnits[0]?.id,
        false
      );
      refreshMeasurementOptions(kpi?.measurementUnit || defaultMeasurementUnit);
      $("#kpiComposerTitle").textContent = kpi ? "تعديل مؤشر" : "مؤشر جديد";

      if (kpi) {
        Object.entries(kpi).forEach(([key, value]) => {
          if (form.elements[key]) form.elements[key].value = value ?? "";
        });
        form.elements.id.value = kpi.id;
        form.elements.code.value = kpi.code || kpi.id;
      } else {
        form.elements.id.value = "";
        form.elements.formula.value = "الفعلي ÷ المستهدف × 100";
        form.elements.owner.value = composerUnits.find((unit) => unit.id === form.elements.unitId.value)?.name || "";
      }

      updatePreview();
      modal.hidden = false;
      form.elements.name.focus();
    }

    function closeModal() {
      modal.hidden = true;
    }

    modal.addEventListener("click", (event) => {
      if (event.target === modal || event.target.dataset.closeKpiModal !== undefined) {
        closeModal();
      }
    });

    form.elements.unitId.addEventListener("change", () => {
      if (!form.elements.owner.value) {
        form.elements.owner.value = composerUnits.find((unit) => unit.id === form.elements.unitId.value)?.name || "";
      }
    });
    form.addEventListener("input", updatePreview);

    $("[data-add-measurement-unit]", modal).addEventListener("click", () => {
      const value = prompt("اكتب وحدة القياس الجديدة");
      const measurementUnit = String(value || "").trim();
      if (!measurementUnit) return;

      const existingUnit = state.measurementUnits.find((item) => item.trim() === measurementUnit);
      if (existingUnit) {
        refreshMeasurementOptions(existingUnit);
        message.textContent = "وحدة القياس موجودة مسبقًا وتم اختيارها.";
        return;
      }

      state = MRM.addMeasurementUnit(measurementUnit, session);
      refreshMeasurementOptions(measurementUnit);
      message.textContent = "تمت إضافة وحدة القياس الجديدة ويمكن استخدامها الآن.";
    });

    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const data = Object.fromEntries(new FormData(form));
      const code = String(data.code || "").trim();
      const originalId = String(data.id || "");
      const selectedUnitId = session.role === "unit" ? session.unitId : data.unitId;
      const requestNeedsApproval = session.role === "unit";
      const duplicate = state.kpis.some((kpi) => kpi.id !== originalId && (kpi.id === code || kpi.code === code));

      if (duplicate) {
        message.textContent = "رمز المؤشر مستخدم مسبقًا.";
        return;
      }

      MRM.upsertKpi(
        {
          id: originalId || code,
          code,
          unitId: selectedUnitId,
          name: data.name,
          domain: data.type,
          type: data.type,
          objective: data.objective,
          initiative: data.initiative,
          definition: data.definition,
          formula: data.formula,
          measurementUnit: data.measurementUnit,
          baseline: Number(data.baseline || 0),
          annualTarget: Number(data.annualTarget || 0),
          periodicTarget: Number(data.periodicTarget || data.annualTarget || 0),
          actual: Number(data.actual || 0),
          polarity: data.polarity,
          performanceMethod: data.polarity,
          performanceDirection: data.polarity === "تنازلي" ? "خفض المؤشر" : "رفع المؤشر",
          greenThreshold: Number(data.greenThreshold || 90),
          yellowThreshold: Number(data.yellowThreshold || 70),
          frequency: data.frequency,
          dataSource: data.dataSource,
          dataOwner: data.dataOwner,
          owner: data.owner,
          evidenceLink: data.evidenceLink,
          deviationReason: data.deviationReason,
          correctiveOwner: data.correctiveOwner,
          correctiveStatus: data.correctiveStatus,
          correctiveProgress: Number(data.correctiveProgress || 0),
          weight: 0,
          approved: requestNeedsApproval ? false : true,
          workflowStatus: requestNeedsApproval ? "مرسل للاعتماد" : "معتمد",
          submittedBy: session.name,
          submittedByUserId: session.userId,
          submittedAt: new Date().toISOString()
        },
        session
      );

      closeModal();
      window.location.reload();
    });

    document.addEventListener("click", (event) => {
      if (event.target.dataset.newKpi !== undefined) {
        openModal();
      }
    });

    MRM.openKpiComposer = openModal;
  }

  function applyCommonUi(session) {
    const current = window.location.pathname.split("/").pop() || "index.html";
    $all(".nav-link").forEach((link) => {
      if (link.getAttribute("href") === current) {
        link.classList.add("is-active");
      }
    });

    $("[data-user-badge]") && ($("[data-user-badge]").textContent = session.name);
    $("[data-logout]")?.addEventListener("click", MRM.logout);

    if (session.role !== "admin") {
      $all("[data-admin-only]").forEach((element) => {
        element.hidden = true;
      });
    }
  }

  async function initLoginPage() {
    const state = await MRM.initStore();
    const select = $("#loginUserSelect");
    const message = $("#loginMessage");

    select.innerHTML = state.users
      .map((user) => {
        const scope = user.role === "admin" ? "كامل النظام" : MRM.unitName(user.unitId);
        return `<option value="${user.id}">${escapeHtml(user.name)} - ${escapeHtml(scope)}</option>`;
      })
      .join("");

    $("#loginForm").addEventListener("submit", async (event) => {
      event.preventDefault();
      const form = new FormData(event.currentTarget);
      try {
        await MRM.login(form.get("userId"), form.get("password"));
        window.location.href = "dashboard.html";
      } catch (error) {
        message.textContent = error.message;
      }
    });
  }

  function renderDashboard(state, session) {
    const rows = MRM.visibleKpis(state, session);
    const summary = MRM.summarizeRows(rows);
    const mainSummaryCards = [
      ["عدد المؤشرات", summary.count, "total"],
      ["متوسط الأداء", summary.averageText, "average"],
      ["المعتمدة", summary.approved, "approved"],
      ["غير المعتمدة", summary.count - summary.approved, "pending"],
      ["غير المحدثة", summary.notUpdated, "pending"],
      ["بدون دليل", summary.withoutEvidence, "pending"],
      ["متوسط جودة البيانات", summary.averageDataQualityText, "approved"],
      ["إجراءات تصحيحية", summary.correctiveActions, "pending"]
    ];
    const statusSummaryCards = [
      ["مؤشرات خضراء", summary.green, "green"],
      ["مؤشرات صفراء", summary.yellow, "yellow"],
      ["مؤشرات حمراء", summary.red, "red"]
    ];

    $("#summaryCards").innerHTML = `
      ${mainSummaryCards
        .map(
          ([label, value, tone]) =>
            `<article class="summary-card summary-card-${tone}"><span>${label}</span><strong>${value}</strong></article>`
        )
        .join("")}
      <div class="summary-status-row" aria-label="ملخص حالات المؤشرات">
        ${statusSummaryCards
          .map(
            ([label, value, tone]) =>
              `<article class="summary-card summary-card-status summary-card-${tone}"><span>${label}</span><strong>${value}</strong></article>`
          )
          .join("")}
      </div>
    `;

    const grouped = MRM.groupByUnit(rows, state);
    $("#unitPerformanceTable").innerHTML = grouped.length
      ? grouped
          .map(
            (item) => `<tr>
              <td>${escapeHtml(item.unit.name)}</td>
              <td>${item.count}</td>
              <td>${item.averageText}</td>
              <td>${statusBadge(item.statusKey, item.statusLabel)}</td>
            </tr>`
          )
          .join("")
      : emptyRow("لا توجد مؤشرات متاحة.", 4);

    const riskyRows = rows.filter((item) => item.statusKey !== "green").slice(0, 8);
    $("#riskTable").innerHTML = riskyRows.length
      ? riskyRows
          .map(
            (item) => `<tr>
              <td>${escapeHtml(item.name)}</td>
              <td>${escapeHtml(item.unitShortName)}</td>
              <td>${item.performanceText}</td>
              <td>${escapeHtml(item.correctiveAction || "لم يحدد")}</td>
            </tr>`
          )
          .join("")
      : emptyRow("لا توجد مؤشرات تحتاج متابعة.", 4);

    MRM.renderUnitChart?.(rows, state);
    MRM.renderStatusChart?.(summary);
    MRM.renderTypeChart?.(rows);
    MRM.renderFrequencyChart?.(rows);
    MRM.renderInterventionChart?.(rows, state);
    MRM.renderTopBottomKpisChart?.(rows, "top", "topKpisChart");
    MRM.renderTopBottomKpisChart?.(rows, "bottom", "bottomKpisChart");
  }

  function renderEntryTable(state, unitId) {
    const rows = state.kpis
      .filter((kpi) => kpi.unitId === unitId)
      .map((kpi) => MRM.enrichKpi(kpi, state));

    $("#entryTableBody").innerHTML = rows.length
      ? rows
          .map(
            (item) => `<tr data-kpi-id="${item.id}">
              <td>
                <strong>${escapeHtml(item.name)}</strong>
                <div class="muted">${escapeHtml(item.domain)} - ${escapeHtml(item.frequency)}</div>
              </td>
              <td><input class="metric-input" data-field="annualTarget" type="number" min="0" step="0.01" value="${item.annualTarget}"></td>
              <td><input class="metric-input" data-field="periodicTarget" type="number" min="0" step="0.01" value="${item.periodicTarget || item.annualTarget}"></td>
              <td><input class="metric-input" data-field="actual" type="number" min="0" step="0.01" value="${item.actual}"></td>
              <td>${item.performanceText}</td>
              <td>${statusBadge(item.statusKey, item.statusLabel)}</td>
              <td>${item.dataQualityText}</td>
              <td>${escapeHtml(item.workflowStatus || "مسودة")}</td>
              <td><input class="text-input" data-field="notes" value="${escapeHtml(item.notes)}"></td>
              <td><input class="text-input" data-field="deviationReason" value="${escapeHtml(item.deviationReason)}"></td>
              <td><input class="text-input" data-field="correctiveAction" value="${escapeHtml(item.correctiveAction)}"></td>
              <td><input class="text-input" data-field="evidenceLink" value="${escapeHtml(item.evidenceLink)}"></td>
            </tr>`
          )
          .join("")
      : emptyRow("لا توجد مؤشرات لهذه الوحدة.", 12);
  }

  function initEntryPage(state, session) {
    const unitSelect = $("#entryUnitSelect");
    const year = $("#entryYear");
    const period = $("#entryPeriod");
    const monthsButton = $("#entryMonthsButton");
    const monthsPanel = $("#entryMonthsPanel");
    const monthChecks = $("#entryMonthChecks");
    const monthsSummary = $("#entryMonthsSummary");
    const selectedUnitId = session.role === "unit" ? session.unitId : state.units[0]?.id;

    function monthsForPeriod(value) {
      return MRM.DEFAULT_PERIOD_MONTHS?.[value] || MRM.DEFAULT_PERIOD_MONTHS?.["الربع الأول"] || [1, 2, 3];
    }

    function selectedMonths() {
      const checked = $all("input[type='checkbox']:checked", monthChecks).map((input) => Number(input.value));
      return checked.sort((a, b) => a - b);
    }

    function renderMonthChecks(months) {
      const activeMonths = new Set(months.map((month) => Number(month)));
      monthChecks.innerHTML = monthLabels
        .map((label, index) => {
          const month = index + 1;
          return `<label class="month-check ${activeMonths.has(month) ? "is-selected" : ""}">
            <input type="checkbox" value="${month}" ${activeMonths.has(month) ? "checked" : ""}>
            <span>${label}</span>
          </label>`;
        })
        .join("");
      updateMonthsSummary();
    }

    function updateMonthsSummary() {
      const months = selectedMonths();
      const text = months.length ? months.map((month) => `شهر ${month}`).join("، ") : "لا توجد شهور محددة";
      monthsSummary.textContent = text;
      monthsButton.textContent = months.length ? `الشهور: ${months.join("، ")}` : "الشهور المحددة";
      $all(".month-check", monthChecks).forEach((label) => {
        label.classList.toggle("is-selected", label.querySelector("input").checked);
      });
    }

    unitSelect.innerHTML = unitOptions(state.units, selectedUnitId, false);
    unitSelect.disabled = session.role === "unit";
    year.value = state.meta.year;
    period.value = state.meta.period;
    renderMonthChecks(state.meta.months?.length ? state.meta.months : monthsForPeriod(period.value));
    $("#entryPeriodStatus").textContent = state.meta.periodStatus || "مفتوحة للإدخال";
    $("#entryScopeLabel").textContent = session.role === "unit" ? MRM.unitName(session.unitId) : "إدخال بيانات الوحدات";

    renderEntryTable(state, unitSelect.value);
    unitSelect.addEventListener("change", () => renderEntryTable(state, unitSelect.value));
    period.addEventListener("change", () => {
      renderMonthChecks(monthsForPeriod(period.value));
      monthsPanel.hidden = false;
    });
    monthsButton.addEventListener("click", () => {
      monthsPanel.hidden = !monthsPanel.hidden;
    });
    monthChecks.addEventListener("change", updateMonthsSummary);

    $("#entrySaveButton").addEventListener("click", async () => {
      if (session.role !== "admin" && ["معتمدة", "مغلقة"].includes(state.meta.periodStatus)) {
        $("#entryMessage").textContent = "لا يمكن تعديل البيانات بعد اعتماد أو إغلاق الفترة.";
        return;
      }
      const rows = $all("#entryTableBody tr[data-kpi-id]");
      const months = selectedMonths();
      if (!months.length) {
        $("#entryMessage").textContent = "اختر شهرًا واحدًا على الأقل قبل حفظ التحديثات.";
        monthsPanel.hidden = false;
        return;
      }
      const validationErrors = [];
      rows.forEach((row) => {
        const current = state.kpis.find((kpi) => kpi.id === row.dataset.kpiId);
        const patch = {};
        $all("[data-field]", row).forEach((input) => {
          const field = input.dataset.field;
          patch[field] = ["annualTarget", "periodicTarget", "actual"].includes(field)
            ? Number(input.value)
            : input.value;
        });
        const preview = MRM.enrichKpi({ ...current, ...patch }, state);
        if (preview.statusKey === "red" && !String(patch.correctiveAction || "").trim()) {
          validationErrors.push(`${preview.name}: الإجراء التصحيحي إلزامي عند الحالة الحمراء.`);
        }
        if (preview.performance < 100 && !String(patch.deviationReason || "").trim()) {
          validationErrors.push(`${preview.name}: سبب الانحراف إلزامي عند الأداء الأقل من المستهدف.`);
        }
      });

      if (validationErrors.length) {
        $("#entryMessage").textContent = validationErrors[0];
        return;
      }

      state.meta.year = Number(year.value || new Date().getFullYear());
      state.meta.period = period.value;
      state.meta.months = months;
      state.meta.periodStatus = "محفوظة من الوحدة";
      MRM.saveState(state);

      rows.forEach((row) => {
        const patch = {};
        $all("[data-field]", row).forEach((input) => {
          const field = input.dataset.field;
          patch[field] = ["annualTarget", "periodicTarget", "actual"].includes(field)
            ? Number(input.value)
            : input.value;
        });
        MRM.updateKpi(row.dataset.kpiId, patch, session);
      });

      state = await MRM.initStore();
      monthsPanel.hidden = true;
      $("#entryMessage").textContent = `تم حفظ تحديثات ${state.meta.period} للشهور: ${state.meta.months.join("، ")}.`;
      $("#entryPeriodStatus").textContent = state.meta.periodStatus || "محفوظة من الوحدة";
      renderEntryTable(state, unitSelect.value);
    });

    $("#sendReviewButton").addEventListener("click", async () => {
      state = MRM.setPeriodStatus("قيد المراجعة", session);
      $("#entryPeriodStatus").textContent = state.meta.periodStatus;
      $("#entryMessage").textContent = "تم إرسال الفترة للمراجعة.";
    });
  }

  function initLibraryPage(state, session) {
    function renderTable() {
      const rows = MRM.visibleKpis(state, session);
      $("#kpiLibraryBody").innerHTML = rows.length
        ? rows
            .map(
              (item) => `<tr>
                <td>${escapeHtml(item.code || item.id)}</td>
                <td>${escapeHtml(item.name)}</td>
                <td>${escapeHtml(item.unitShortName)}</td>
                <td>${escapeHtml(item.type)}</td>
                <td>${escapeHtml(item.frequency)}</td>
                <td>${escapeHtml(item.polarity)}</td>
                <td>${escapeHtml(item.workflowStatus || (item.approved ? "معتمد" : "مسودة"))}</td>
                ${
                  session.role === "admin"
                    ? `<td>
                        ${
                          !item.approved
                            ? `<button class="button primary small-button" data-approve-kpi="${item.id}" type="button">اعتماد</button>`
                            : ""
                        }
                        <button class="button ghost small-button" data-edit-kpi="${item.id}" type="button">تعديل</button>
                        <button class="button danger small-button" data-delete-kpi="${item.id}" type="button">حذف</button>
                      </td>`
                    : ""
                }
              </tr>`
            )
            .join("")
        : emptyRow("لا توجد مؤشرات.", session.role === "admin" ? 8 : 7);
    }

    renderTable();

    if (session.role !== "admin") {
      return;
    }

    $("#kpiLibraryBody").addEventListener("click", async (event) => {
      const editId = event.target.dataset.editKpi;
      const deleteId = event.target.dataset.deleteKpi;
      const approveId = event.target.dataset.approveKpi;

      if (approveId) {
        MRM.approveKpis([approveId], session);
        state = await MRM.initStore();
        renderTable();
        $("#libraryNotice").textContent = "تم اعتماد المؤشر وإضافته ضمن التحديثات المعتمدة.";
        return;
      }

      if (editId) {
        const item = state.kpis.find((kpi) => kpi.id === editId);
        if (!item) return;
        MRM.openKpiComposer?.(item);
      }

      if (deleteId && confirm("هل تريد حذف هذا المؤشر؟")) {
        MRM.deleteKpi(deleteId, session);
        state = await MRM.initStore();
        renderTable();
      }
    });
  }

  function initReportsPage(state, session) {
    const unitFilter = $("#reportUnitFilter");
    const statusFilter = $("#reportStatusFilter");
    const typeFilter = $("#reportTypeFilter");
    const frequencyFilter = $("#reportFrequencyFilter");
    const qualityFilter = $("#reportQualityFilter");
    const visibleUnits = session.role === "unit"
      ? state.units.filter((unit) => unit.id === session.unitId)
      : state.units;

    unitFilter.innerHTML = unitOptions(visibleUnits, session.unitId, session.role === "admin");
    unitFilter.disabled = session.role === "unit";
    typeFilter.innerHTML = `<option value="all">الكل</option>${MRM.groupCountBy(MRM.visibleKpis(state, session), "type").map((item) => `<option value="${escapeHtml(item.label)}">${escapeHtml(item.label)}</option>`).join("")}`;
    frequencyFilter.innerHTML = `<option value="all">الكل</option>${MRM.groupCountBy(MRM.visibleKpis(state, session), "frequency").map((item) => `<option value="${escapeHtml(item.label)}">${escapeHtml(item.label)}</option>`).join("")}`;
    $("#reportPeriodStatus").textContent = state.meta.periodStatus || "مفتوحة للإدخال";

    function filteredRows() {
      let rows = MRM.visibleKpis(state, session);
      if (unitFilter.value !== "all") {
        rows = rows.filter((item) => item.unitId === unitFilter.value);
      }
      if (statusFilter.value !== "all") {
        rows = rows.filter((item) => item.statusKey === statusFilter.value);
      }
      if (typeFilter.value !== "all") {
        rows = rows.filter((item) => item.type === typeFilter.value);
      }
      if (frequencyFilter.value !== "all") {
        rows = rows.filter((item) => item.frequency === frequencyFilter.value);
      }
      if (qualityFilter.value === "high") rows = rows.filter((item) => item.dataQuality >= 80);
      if (qualityFilter.value === "medium") rows = rows.filter((item) => item.dataQuality >= 60 && item.dataQuality < 80);
      if (qualityFilter.value === "low") rows = rows.filter((item) => item.dataQuality < 60);
      return rows;
    }

    function renderExecutiveSummary(rows, summary) {
      const units = MRM.groupByUnit(rows, state);
      const topUnit = units[0]?.unit?.shortName || "غير محدد";
      const lowUnit = units[units.length - 1]?.unit?.shortName || "غير محدد";
      const redRows = rows.filter((item) => item.statusKey === "red");
      $("#reportExecutiveSummary").innerHTML = [
        `الوضع العام للأداء: ${summary.averageText} عبر ${summary.count} مؤشر.`,
        `أبرز الانحرافات: ${redRows.length} مؤشر في الحالة الحمراء.`,
        `أعلى وحدة أداء: ${escapeHtml(topUnit)}.`,
        `الأكثر احتياجًا للتدخل: ${escapeHtml(lowUnit)}.`,
        `متوسط جودة البيانات: ${summary.averageDataQualityText}.`
      ].map((text) => `<article>${text}</article>`).join("");
    }

    function render() {
      const rows = filteredRows();
      const summary = MRM.summarizeRows(rows);
      $("#reportTableBody").innerHTML = rows.length
        ? rows
            .map(
              (item) => `<tr>
                <td>${escapeHtml(item.unitShortName)}</td>
                <td>${escapeHtml(item.name)}</td>
                <td>${item.periodicTarget || item.annualTarget}</td>
                <td>${item.actual}</td>
                <td>${item.performanceText}</td>
                <td>${statusBadge(item.statusKey, item.statusLabel)}</td>
                <td>${item.dataQualityText}</td>
                <td>${item.approved ? "معتمد" : "غير معتمد"}</td>
              </tr>`
            )
            .join("")
        : emptyRow("لا توجد نتائج مطابقة.", 8);

      const actionRows = rows.filter((item) => item.correctiveAction || item.statusKey !== "green");
      $("#correctiveActionsBody").innerHTML = actionRows.length
        ? actionRows
            .map(
              (item) => `<tr>
                <td>${escapeHtml(item.name)}</td>
                <td>${statusBadge(item.statusKey, item.statusLabel)}</td>
                <td>${escapeHtml(item.correctiveAction || "لم يحدد")}</td>
              </tr>`
            )
            .join("")
        : emptyRow("لا توجد إجراءات تصحيحية.", 3);

      MRM.renderStatusChart?.(summary, "reportStatusDistributionChart");
      MRM.renderUnitChart?.(rows, state, "reportUnitPerformanceChart");
      MRM.renderTypeChart?.(rows, "reportTypeDistributionChart");
      MRM.renderFrequencyChart?.(rows, "reportFrequencyDistributionChart");
      MRM.renderOwnerChart?.(rows, "reportOwnerDistributionChart");
      renderExecutiveSummary(rows, summary);
    }

    unitFilter.addEventListener("change", render);
    statusFilter.addEventListener("change", render);
    typeFilter.addEventListener("change", render);
    frequencyFilter.addEventListener("change", render);
    qualityFilter.addEventListener("change", render);

    $("#approvePeriodButton")?.addEventListener("click", async () => {
      const rows = filteredRows();
      MRM.approveKpis(rows.map((item) => item.id), session);
      MRM.setPeriodStatus("معتمدة", session);
      state = await MRM.initStore();
      $("#reportMessage").textContent = "تم اعتماد المؤشرات المعروضة.";
      $("#reportPeriodStatus").textContent = state.meta.periodStatus;
      render();
    });

    $("#returnPeriodButton")?.addEventListener("click", async () => {
      const reason = prompt("سبب الإرجاع للتصحيح") || "";
      state = MRM.setPeriodStatus("معادة للتصحيح", session, reason);
      $("#reportMessage").textContent = "تم إرجاع الفترة للتصحيح.";
      $("#reportPeriodStatus").textContent = state.meta.periodStatus;
      render();
    });

    render();
  }

  function initAdminPage(state, session) {
    if (!MRM.requireAdmin(session)) return;

    function formatDate(value) {
      if (!value) return "لم تعدل بعد";
      return new Intl.DateTimeFormat("ar-SA", {
        dateStyle: "medium",
        timeStyle: "short"
      }).format(new Date(value));
    }

    function userScope(user) {
      return user.role === "admin" ? "كل الوحدات" : MRM.unitName(user.unitId);
    }

    function userRoleLabel(user) {
      if (user.role === "admin" && user.id === "admin") return "مدير النظام";
      if (user.role === "admin") return "حساب عام";
      return user.parentUnitId ? "إدارة عامة" : "وكالة مساعدة";
    }

    function unitForUser(user) {
      return state.units.find((unit) => unit.id === user.unitId);
    }

    function parentName(parentUnitId) {
      if (!parentUnitId) return "غير محدد";
      return state.units.find((unit) => unit.id === parentUnitId)?.name || "غير محدد";
    }

    function accountName(user) {
      return unitForUser(user)?.name || user.name;
    }

    function accountShortName(user) {
      return unitForUser(user)?.shortName || user.name;
    }

    function parentOptions(selected) {
      return `<option value="">بدون تبعية</option>${state.units
        .map((unit) => `<option value="${unit.id}" ${unit.id === selected ? "selected" : ""}>${escapeHtml(unit.name)}</option>`)
        .join("")}`;
    }

    const accountForm = $("#accountForm");
    const accountMessage = $("#accountMessage");

    function resetAccountForm() {
      accountForm.elements.userId.value = "";
      accountForm.elements.type.value = "department";
      accountForm.elements.type.disabled = false;
      accountForm.elements.name.value = "";
      accountForm.elements.shortName.value = "";
      accountForm.elements.parentUnitId.innerHTML = parentOptions("");
      accountForm.elements.parentUnitId.value = "";
      accountForm.elements.password.value = "demo";
      accountForm.elements.shortName.disabled = false;
      accountForm.elements.parentUnitId.disabled = false;
      accountMessage.textContent = "";
    }

    function renderAccountRows() {
      accountForm.elements.parentUnitId.innerHTML = parentOptions(accountForm.elements.parentUnitId.value);
      $("#adminAccountsBody").innerHTML = state.users
        .map((user) => {
          const unit = unitForUser(user);
          const canDelete = Boolean(user.customAccount);
          const canEdit = user.id !== "admin";
          return `<tr>
            <td><strong>${escapeHtml(accountName(user))}</strong></td>
            <td>${escapeHtml(accountShortName(user))}</td>
            <td>${userRoleLabel(user)}</td>
            <td>${user.role === "admin" ? "صلاحية عامة" : escapeHtml(parentName(unit?.parentUnitId || user.parentUnitId))}</td>
            <td>${escapeHtml(userScope(user))}</td>
            <td>${formatDate(user.passwordUpdatedAt)}</td>
            <td>
              <div class="table-actions">
                ${
                  canEdit
                    ? `<button type="button" class="button ghost small-button" data-edit-account="${user.id}">تعديل</button>`
                    : `<span class="muted">أساسي</span>`
                }
                ${
                  canDelete
                    ? `<button type="button" class="button danger small-button" data-delete-account="${user.id}">حذف</button>`
                    : ""
                }
              </div>
            </td>
          </tr>`;
        })
        .join("");
    }

    function renderPasswordRows() {
      $("#adminPasswordsBody").innerHTML = state.users
        .map((user) => {
          const scope = userScope(user);
          return `<tr>
            <td>${escapeHtml(accountName(user))}</td>
            <td>${userRoleLabel(user)}</td>
            <td>${escapeHtml(scope)}</td>
            <td>${formatDate(user.passwordUpdatedAt)}</td>
          </tr>`;
        })
        .join("");
    }

    const passwordForm = $("#passwordForm");
    function refreshPasswordUserOptions() {
      passwordForm.elements.userId.innerHTML = state.users
        .map((user) => `<option value="${user.id}">${escapeHtml(accountName(user))} - ${escapeHtml(userScope(user))}</option>`)
        .join("");
    }

    resetAccountForm();
    renderAccountRows();
    refreshPasswordUserOptions();
    renderPasswordRows();

    accountForm.addEventListener("reset", (event) => {
      event.preventDefault();
      resetAccountForm();
    });

    accountForm.elements.type.addEventListener("change", () => {
      const isGeneral = accountForm.elements.type.value === "general";
      accountForm.elements.shortName.disabled = isGeneral;
      accountForm.elements.parentUnitId.disabled = isGeneral;
    });

    accountForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const data = Object.fromEntries(new FormData(accountForm));
      const result = MRM.upsertAccountRecord(data, session);
      if (!result) {
        accountMessage.textContent = "تعذر حفظ الحساب. تأكد من إدخال اسم النطاق.";
        return;
      }
      state = await MRM.initStore();
      resetAccountForm();
      renderAccountRows();
      refreshPasswordUserOptions();
      renderPasswordRows();
      refreshAuditFilters();
      renderAuditTrail();
      accountMessage.textContent = "تم حفظ النطاق والحساب.";
    });

    $("#adminAccountsBody").addEventListener("click", async (event) => {
      const editId = event.target.dataset.editAccount;
      const deleteId = event.target.dataset.deleteAccount;

      if (editId) {
        const user = state.users.find((item) => item.id === editId);
        if (!user) return;
        const unit = unitForUser(user);
        accountForm.elements.userId.value = user.id;
        accountForm.elements.type.value = user.role === "admin" ? "general" : "department";
        accountForm.elements.type.disabled = false;
        accountForm.elements.name.value = accountName(user);
        accountForm.elements.shortName.value = unit?.shortName || "";
        accountForm.elements.parentUnitId.innerHTML = parentOptions(unit?.parentUnitId || user.parentUnitId || "");
        accountForm.elements.parentUnitId.value = unit?.parentUnitId || user.parentUnitId || "";
        accountForm.elements.password.value = "";
        accountForm.elements.shortName.disabled = user.role === "admin";
        accountForm.elements.parentUnitId.disabled = user.role === "admin";
        accountMessage.textContent = "وضع التعديل مفعّل. احفظ التغييرات عند الانتهاء.";
      }

      if (deleteId) {
        const user = state.users.find((item) => item.id === deleteId);
        if (!user) return;
        if (!confirm(`هل تريد حذف حساب ${accountName(user)}؟`)) return;
        const result = MRM.deleteAccountRecord(deleteId, session);
        accountMessage.textContent = result.message;
        state = await MRM.initStore();
        resetAccountForm();
        renderAccountRows();
        refreshPasswordUserOptions();
        renderPasswordRows();
        refreshAuditFilters();
        renderAuditTrail();
      }
    });

    passwordForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const data = Object.fromEntries(new FormData(passwordForm));
      const message = $("#passwordMessage");

      if (String(data.password).length < 4) {
        message.textContent = "كلمة المرور يجب أن تكون 4 أحرف على الأقل.";
        return;
      }

      if (data.password !== data.confirmPassword) {
        message.textContent = "كلمة المرور وتأكيدها غير متطابقين.";
        return;
      }

      MRM.updateUserPassword(data.userId, data.password, session);
      state = await MRM.initStore();
      passwordForm.reset();
      refreshPasswordUserOptions();
      renderPasswordRows();
      refreshAuditFilters();
      renderAuditTrail();
      message.textContent = "تم تحديث كلمة المرور.";
    });

    const auditActorFilter = $("#auditActorFilter");
    const auditActionFilter = $("#auditActionFilter");

    function refreshAuditFilters() {
      const logs = state.auditLog || [];
      const actors = Array.from(new Set(logs.map((item) => item.actor).filter(Boolean)));
      const actions = Array.from(new Set(logs.map((item) => item.action).filter(Boolean)));
      auditActorFilter.innerHTML = `<option value="all">الكل</option>${actors.map((actor) => `<option value="${escapeHtml(actor)}">${escapeHtml(actor)}</option>`).join("")}`;
      auditActionFilter.innerHTML = `<option value="all">الكل</option>${actions.map((action) => `<option value="${escapeHtml(action)}">${escapeHtml(action)}</option>`).join("")}`;
    }

    function renderAuditTrail() {
      const logs = (state.auditLog || []).filter((item) => {
        const actorOk = auditActorFilter.value === "all" || item.actor === auditActorFilter.value;
        const actionOk = auditActionFilter.value === "all" || item.action === auditActionFilter.value;
        return actorOk && actionOk;
      });
      $("#auditTrailBody").innerHTML = logs.length
        ? logs
            .slice(0, 80)
            .map(
              (item) => `<tr>
                <td>${formatDate(item.createdAt)}</td>
                <td>${escapeHtml(item.actor)}</td>
                <td>${escapeHtml(item.action)}</td>
                <td>${escapeHtml(item.page || "")}</td>
                <td>${escapeHtml(item.details || "")}</td>
              </tr>`
            )
            .join("")
        : emptyRow("لا توجد عمليات مطابقة.", 5);
    }

    refreshAuditFilters();
    renderAuditTrail();
    auditActorFilter.addEventListener("change", renderAuditTrail);
    auditActionFilter.addEventListener("change", renderAuditTrail);

    $("#downloadBackupButton").addEventListener("click", () => {
      MRM.exportBackup(state);
      $("#adminMessage").textContent = "تم تنزيل النسخة الاحتياطية.";
    });

    $("#restoreBackupInput").addEventListener("change", (event) => {
      const file = event.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const nextState = JSON.parse(reader.result);
          state = MRM.replaceState(nextState, session);
          $("#adminMessage").textContent = "تمت استعادة النسخة.";
          window.location.reload();
        } catch (error) {
          $("#adminMessage").textContent = "ملف النسخة غير صالح.";
        }
      };
      reader.readAsText(file);
    });

    $("#resetSeedButton").addEventListener("click", async () => {
      if (!confirm("سيتم استبدال البيانات المحلية بالبيانات الأولية. هل تريد المتابعة؟")) return;
      await MRM.resetSeed(session);
      window.location.reload();
    });
  }

  function initExportPage(state, session) {
    const sheets = [
      ["Executive Dashboard", "ملخص تنفيذي وعدد المؤشرات والحالات"],
      ["All KPIs", "كل المؤشرات وقيم الأداء"],
      ["Unit Performance", "متوسط أداء كل وحدة"],
      ["Monthly Actuals", "المستهدف والفعلي حسب الفترة"],
      ["Red Indicators", "المؤشرات الحمراء"],
      ["Corrective Actions", "الإجراءات التصحيحية"],
      ["Audit Log", "سجل التعديلات المحلي"],
      ["Data Quality", "درجة جودة البيانات والتحديث والدليل"],
      ["Period Approval", "حالة اعتماد الفترة والاعتماد والإعادة"],
      ["PowerPoint", "عرض تنفيذي بصيغة PPTX"],
      ["PDF", "تقرير قابل للحفظ بصيغة PDF من نافذة الطباعة"]
    ];

    $("#exportPreviewBody").innerHTML = sheets
      .map(([name, description]) => `<tr><td>${name}</td><td>${escapeHtml(description)}</td></tr>`)
      .join("");

    $("#exportExcelButton").addEventListener("click", () => {
      $("#exportMessage").textContent = MRM.exportExcel(state);
      MRM.addAudit("export-excel", session, "تصدير ملف Excel");
    });

    $("#exportCsvButton").addEventListener("click", () => {
      MRM.exportCsv(state);
      $("#exportMessage").textContent = "تم تنزيل CSV.";
      MRM.addAudit("export-csv", session, "تصدير ملف CSV");
    });

    $("#exportBackupButton").addEventListener("click", () => {
      MRM.exportBackup(state);
      $("#exportMessage").textContent = "تم تنزيل نسخة JSON.";
      MRM.addAudit("export-json", session, "تصدير نسخة JSON");
    });

    $("#exportPdfButton").addEventListener("click", () => {
      $("#exportMessage").textContent = MRM.exportPdfReport(state);
      MRM.addAudit("export-pdf", session, "تصدير تقرير PDF");
    });

    $("#exportPptButton").addEventListener("click", () => {
      $("#exportMessage").textContent = MRM.exportPowerPoint(state);
      MRM.addAudit("export-pptx", session, "تصدير عرض PowerPoint");
    });
  }

  async function init() {
    const page = document.body.dataset.page;
    if (page === "login") {
      await initLoginPage();
      return;
    }

    const state = await MRM.initStore();
    const session = MRM.requireSession();
    if (!session) return;

    applyCommonUi(session);
    injectNewKpiButton(page, session);
    initKpiComposer(state, session);

    if (page === "dashboard") renderDashboard(state, session);
    if (page === "unit-entry") initEntryPage(state, session);
    if (page === "kpi-library") initLibraryPage(state, session);
    if (page === "reports") initReportsPage(state, session);
    if (page === "admin") initAdminPage(state, session);
    if (page === "export-excel") initExportPage(state, session);
  }

  document.addEventListener("DOMContentLoaded", init);
})();
